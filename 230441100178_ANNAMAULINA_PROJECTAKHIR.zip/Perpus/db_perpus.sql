-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 23 Nov 2024 pada 10.00
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_perpus`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_aktivitas`
--

CREATE TABLE `t_aktivitas` (
  `id` int(11) NOT NULL,
  `aktivitas` text NOT NULL,
  `tglWaktu` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `t_aktivitas`
--

INSERT INTO `t_aktivitas` (`id`, `aktivitas`, `tglWaktu`) VALUES
(1, 'Menambahkan data buku baru dengan ISBN 3646464333', '2024-11-18 14:38:03'),
(2, 'Memperbarui data buku dengan ISBN 3646464333', '2024-11-18 14:44:04'),
(3, 'Memperbarui data anggota dengan NIM 20444444322888', '2024-11-18 14:45:41'),
(4, 'Peminjaman buku dengan ISBN 1232134565567', '2024-11-18 14:47:27'),
(5, 'Menambahkan data anggota baru dengan NIM 230441100180', '2024-11-18 16:06:11'),
(6, 'Peminjaman buku dengan ISBN 45534324234', '2024-11-18 16:08:36'),
(7, 'Peminjaman buku dengan ISBN 1232134564358', '2024-11-19 19:04:45'),
(8, 'Pengembalian buku dengan ID Peminjam 46', '2024-11-19 19:05:23'),
(9, 'Pengembalian buku dengan ID Peminjam 41', '2024-11-19 19:18:45'),
(10, 'Peminjaman buku dengan ISBN 1232134565567', '2024-11-19 19:32:41'),
(11, 'Pengembalian buku dengan ID Peminjam 47', '2024-11-19 19:33:02'),
(12, 'Pengembalian buku dengan ID Peminjam 47', '2024-11-19 19:36:03'),
(13, 'Pengembalian buku dengan ID Peminjam 42', '2024-11-19 19:37:21'),
(14, 'Pengembalian buku dengan ID Peminjam 41', '2024-11-19 19:38:45'),
(15, 'Peminjaman buku dengan ISBN 1232134564358', '2024-11-21 09:46:48'),
(16, 'Peminjaman buku dengan ISBN 1232134564358', '2024-11-21 09:47:58'),
(17, 'Pengembalian buku dengan ID Peminjam 49', '2024-11-21 09:50:20'),
(18, 'Pengembalian buku dengan ID Peminjam 49', '2024-11-21 09:51:20'),
(19, 'Memperbarui data buku dengan ISBN 9786026238788', '2024-11-21 12:09:25'),
(20, 'Memperbarui data buku dengan ISBN 1232', '2024-11-21 12:10:14'),
(21, 'Memperbarui data buku dengan ISBN 48484', '2024-11-21 12:10:32'),
(22, 'Memperbarui data buku dengan ISBN 4553', '2024-11-21 12:10:45'),
(23, 'Memperbarui data buku dengan ISBN 9786', '2024-11-21 12:11:00'),
(24, 'Memperbarui data buku dengan ISBN 48484', '2024-11-21 12:13:25'),
(25, 'Memperbarui data buku dengan ISBN 48484', '2024-11-21 12:13:39'),
(26, 'Memperbarui data buku dengan ISBN 1232', '2024-11-21 12:13:50'),
(27, 'Memperbarui data buku dengan ISBN 9786026238793', '2024-11-21 12:14:32'),
(28, 'Memperbarui data buku dengan ISBN 9786', '2024-11-21 12:14:49'),
(29, 'Memperbarui data buku dengan ISBN 5758', '2024-11-21 12:15:04'),
(30, 'Memperbarui data buku dengan ISBN 8788', '2024-11-21 12:15:19'),
(31, 'Memperbarui data buku dengan ISBN 8789', '2024-11-21 12:15:36'),
(32, 'Memperbarui data buku dengan ISBN 8790', '2024-11-21 12:15:51'),
(33, 'Memperbarui data buku dengan ISBN 8791', '2024-11-21 12:16:03'),
(34, 'Memperbarui data buku dengan ISBN 8792', '2024-11-21 12:16:19'),
(35, 'Memperbarui data buku dengan ISBN 8791', '2024-11-21 12:16:30'),
(36, 'Memperbarui data buku dengan ISBN 8793', '2024-11-21 12:16:47'),
(37, 'Memperbarui data buku dengan ISBN 8794', '2024-11-21 12:17:07'),
(38, 'Memperbarui data buku dengan ISBN 8795', '2024-11-21 12:17:25'),
(39, 'Memperbarui data buku dengan ISBN 8796', '2024-11-21 12:17:37'),
(40, 'Memperbarui data buku dengan ISBN 8797', '2024-11-21 12:17:49'),
(41, 'Memperbarui data buku dengan ISBN 8798', '2024-11-21 13:06:03'),
(42, 'Memperbarui data buku dengan ISBN 8799', '2024-11-21 13:06:17'),
(43, 'Memperbarui data buku dengan ISBN 8800', '2024-11-21 13:06:31'),
(44, 'Memperbarui data buku dengan ISBN 8801', '2024-11-21 13:07:00'),
(45, 'Memperbarui data buku dengan ISBN 8802', '2024-11-21 13:07:27'),
(46, 'Memperbarui data buku dengan ISBN 8803', '2024-11-21 13:07:58'),
(47, 'Memperbarui data buku dengan ISBN 8804', '2024-11-21 13:08:13'),
(48, 'Memperbarui data buku dengan ISBN 8805', '2024-11-21 13:08:28'),
(49, 'Memperbarui data buku dengan ISBN 8806', '2024-11-21 13:08:48'),
(50, 'Memperbarui data buku dengan ISBN 8807', '2024-11-21 13:09:03'),
(51, 'Memperbarui data buku dengan ISBN 8808', '2024-11-21 13:09:16'),
(52, 'Memperbarui data buku dengan ISBN 8809', '2024-11-21 13:09:34'),
(53, 'Menghapus buku dengan isbn : 9786026238810', '2024-11-21 13:09:45'),
(54, 'Menghapus buku dengan isbn : 9786026238812', '2024-11-21 13:09:51'),
(55, 'Menghapus buku dengan isbn : 9786026238811', '2024-11-21 13:14:18'),
(56, 'Menghapus buku dengan isbn : 9786026238813', '2024-11-21 13:15:12'),
(57, 'Menghapus buku dengan isbn : 9786026238814', '2024-11-21 13:15:20'),
(58, 'Menghapus buku dengan isbn : 9786026238815', '2024-11-21 13:15:29'),
(59, 'Menghapus buku dengan isbn : 9786026238816', '2024-11-21 13:15:35'),
(60, 'Menghapus buku dengan isbn : 9786026238817', '2024-11-21 13:15:41'),
(61, 'Menghapus buku dengan isbn : 9786026238818', '2024-11-21 13:15:46'),
(62, 'Menghapus buku dengan isbn : 9786026238819', '2024-11-21 13:15:53'),
(63, 'Menghapus buku dengan isbn : 9786026238820', '2024-11-21 13:15:58'),
(64, 'Menghapus buku dengan isbn : 9786026238821', '2024-11-21 13:16:04'),
(65, 'Menghapus buku dengan isbn : 9786026238822', '2024-11-21 13:16:14'),
(66, 'Menghapus buku dengan isbn : 9786026238824', '2024-11-21 13:16:19'),
(67, 'Menghapus buku dengan isbn : 9786026238829', '2024-11-21 13:16:23'),
(68, 'Menghapus buku dengan isbn : 9786026238832', '2024-11-21 13:16:28'),
(69, 'Menghapus buku dengan isbn : 9786026238837', '2024-11-21 13:16:34'),
(70, 'Menghapus buku dengan isbn : 9786026238826', '2024-11-21 13:16:39'),
(71, 'Menghapus buku dengan isbn : 9786026238838', '2024-11-21 13:16:44'),
(72, 'Menghapus buku dengan isbn : 9786026238836', '2024-11-21 13:16:51'),
(73, 'Menghapus buku dengan isbn : 9786026238833', '2024-11-21 13:16:57'),
(74, 'Menghapus buku dengan isbn : 9786026238827', '2024-11-21 13:17:01'),
(75, 'Menghapus buku dengan isbn : 9786026238830', '2024-11-21 13:17:05'),
(76, 'Menghapus buku dengan isbn : 9786026238825', '2024-11-21 13:17:10'),
(77, 'Menghapus buku dengan isbn : 9786026238823', '2024-11-21 13:17:15'),
(78, 'Menghapus buku dengan isbn : 9786026238831', '2024-11-21 13:17:19'),
(79, 'Menghapus buku dengan isbn : 9786026238834', '2024-11-21 13:17:24'),
(80, 'Menghapus buku dengan isbn : 9786026238835', '2024-11-21 13:17:30'),
(81, 'Menghapus buku dengan isbn : 9786026238828', '2024-11-21 13:17:38'),
(82, 'Menghapus buku dengan isbn : 9786026238839', '2024-11-21 13:17:44'),
(83, 'Menghapus buku dengan isbn : 9872193302321', '2024-11-21 13:17:49'),
(84, 'Menghapus buku dengan isbn : 9875552223452', '2024-11-21 13:17:56'),
(85, 'Memperbarui data anggota dengan NIM 23098073303', '2024-11-21 13:18:20'),
(86, 'Memperbarui data anggota dengan NIM 23057586586', '2024-11-21 13:18:32'),
(87, 'Memperbarui data anggota dengan NIM 230475757575', '2024-11-21 13:18:47'),
(88, 'Peminjaman buku dengan ISBN 3646464333', '2024-11-21 13:20:16'),
(89, 'Peminjaman buku dengan ISBN 8790', '2024-11-21 13:28:01'),
(90, 'Pengembalian buku dengan ID Peminjam 51', '2024-11-21 13:28:25'),
(91, 'Peminjaman buku dengan ISBN 8791', '2024-11-21 15:57:28'),
(92, 'Pengembalian buku dengan ID Peminjam 52', '2024-11-21 15:58:31'),
(93, 'Menambahkan data buku baru dengan ISBN 3933', '2024-11-21 16:51:38'),
(94, 'Memperbarui data anggota dengan NIM 230848477474', '2024-11-21 16:52:18'),
(95, 'Peminjaman buku dengan ISBN 1232', '2024-11-21 16:53:38'),
(96, 'Pengembalian buku dengan ID Peminjam 53', '2024-11-21 16:54:27'),
(97, 'Peminjaman buku dengan ISBN 48484', '2024-11-21 16:55:37'),
(98, 'Pengembalian buku dengan ID Peminjam 54', '2024-11-21 16:56:04'),
(99, 'Menambahkan data buku baru dengan ISBN 1232', '2024-11-21 16:58:41'),
(100, 'Peminjaman buku dengan ISBN 8788', '2024-11-21 17:00:10'),
(101, 'Peminjaman buku dengan ISBN 8788', '2024-11-21 17:01:01'),
(102, 'Menambahkan data anggota baru dengan NIM 230441100180', '2024-11-22 02:27:07'),
(103, 'Peminjaman buku dengan ISBN 1232', '2024-11-22 06:13:56'),
(104, 'Menambahkan data buku baru dengan ISBN 222', '2024-11-22 15:23:43'),
(105, 'Memperbarui data buku dengan ISBN 222', '2024-11-22 15:24:17'),
(106, 'Menambahkan data buku baru dengan ISBN 4', '2024-11-22 15:33:39'),
(107, 'Menghapus buku dengan isbn : 3933', '2024-11-22 15:33:59'),
(108, 'Menghapus buku dengan isbn : 4', '2024-11-22 15:34:25'),
(109, 'Menambahkan data anggota baru dengan NIM 5', '2024-11-22 16:46:26'),
(110, 'Memperbarui data anggota dengan NIM 5', '2024-11-22 16:47:10'),
(111, 'Peminjaman buku dengan ISBN 1232', '2024-11-22 17:55:29'),
(112, 'Peminjaman buku dengan ISBN 1232', '2024-11-22 18:11:39'),
(113, 'Pengembalian buku dengan ID Peminjam 50', '2024-11-22 19:06:10'),
(114, 'Peminjaman buku dengan ISBN 1232', '2024-11-22 19:07:17'),
(115, 'Menghapus anggota dengan id : 21', '2024-11-23 02:50:35'),
(116, 'Menghapus buku dengan isbn : 1232', '2024-11-23 02:50:46'),
(117, 'Memperbarui data peminjaman dengan ISBN 48484', '2024-11-23 03:08:22'),
(118, 'Memperbarui data peminjaman dengan ISBN 48484', '2024-11-23 04:12:43'),
(119, 'Memperbarui data peminjaman dengan ISBN 48484', '2024-11-23 04:16:27'),
(120, 'Pengembalian buku dengan ID Peminjam 56', '2024-11-23 04:28:21'),
(121, 'Pengembalian buku dengan ID Peminjam 56', '2024-11-23 04:30:46'),
(122, 'Pengembalian buku dengan ID Peminjam 56', '2024-11-23 05:03:39'),
(123, 'Pengembalian buku dengan ID Peminjam 56', '2024-11-23 05:13:02'),
(124, 'Pengembalian buku dengan ID Peminjam 56', '2024-11-23 05:13:45'),
(125, 'Pengembalian buku dengan ID Peminjam 56', '2024-11-23 05:19:37'),
(126, 'Pengembalian buku dengan ID Peminjam 60', '2024-11-23 05:21:01'),
(127, 'Menambahkan data peminjaman baru dengan ISBN 5758', '2024-11-23 05:26:52'),
(128, 'Memperbarui data peminjaman dengan ISBN 48484', '2024-11-23 05:28:07'),
(129, 'Menambahkan data peminjaman baru dengan ISBN 4553', '2024-11-23 05:28:53'),
(130, 'Pengembalian buku dengan ID Peminjam 61', '2024-11-23 05:29:29'),
(131, 'Pengembalian buku dengan ID Peminjam 62', '2024-11-23 05:30:07'),
(132, 'Menambahkan data peminjaman baru dengan ISBN 5758', '2024-11-23 07:34:04'),
(133, 'Memperbarui data peminjaman dengan ISBN 8788', '2024-11-23 07:34:25'),
(134, 'Pengembalian buku dengan ID Peminjam 63', '2024-11-23 07:34:45'),
(135, 'Menambahkan data peminjaman baru dengan ISBN 8789', '2024-11-23 07:44:54'),
(136, 'Menambahkan data anggota baru dengan NIM 230441100178', '2024-11-23 07:50:30'),
(137, 'Menambahkan data anggota baru dengan NIM 230441100200', '2024-11-23 07:51:12'),
(138, 'Menambahkan data anggota baru dengan NIM 230441100201', '2024-11-23 07:51:49'),
(139, 'Menambahkan data anggota baru dengan NIM 230441100204', '2024-11-23 07:52:06'),
(140, 'Menambahkan data anggota baru dengan NIM 230441100207', '2024-11-23 07:52:29'),
(141, 'Menambahkan data peminjaman baru dengan ISBN 8790', '2024-11-23 07:53:39'),
(142, 'Menambahkan data peminjaman baru dengan ISBN 5758', '2024-11-23 07:56:14'),
(143, 'Menambahkan data peminjaman baru dengan ISBN 8808', '2024-11-23 07:56:43'),
(144, 'Pengembalian buku dengan ID Peminjam 65', '2024-11-23 07:58:15'),
(145, 'Pengembalian buku dengan ID Peminjam 67', '2024-11-23 07:59:09'),
(146, 'Menghapus peminjaman dengan id peminjaman : 63', '2024-11-23 08:11:09'),
(147, 'Menghapus peminjaman dengan id peminjaman : 64', '2024-11-23 08:12:08'),
(148, 'Menghapus peminjaman dengan id peminjaman : 67', '2024-11-23 08:17:41'),
(149, 'Menghapus anggota dengan id : 22', '2024-11-23 08:47:46'),
(150, 'Menambahkan data peminjaman baru dengan ISBN 8809', '2024-11-23 08:51:35'),
(151, 'Menambahkan data anggota baru dengan NIM 230111938872', '2024-11-23 10:07:34'),
(152, 'Menambahkan data anggota baru dengan NIM 272727728282', '2024-11-23 10:07:53'),
(153, 'Menambahkan data anggota baru dengan NIM 23049494939', '2024-11-23 10:08:17'),
(154, 'Menambahkan data anggota baru dengan NIM 23874848484', '2024-11-23 10:08:39'),
(155, 'Menambahkan data anggota baru dengan NIM 3489348348934', '2024-11-23 10:09:00'),
(156, 'Menambahkan data anggota baru dengan NIM 2892892892', '2024-11-23 10:09:17'),
(157, 'Menambahkan data anggota baru dengan NIM 203039393', '2024-11-23 10:09:35'),
(158, 'Menambahkan data peminjaman baru dengan ISBN 8807', '2024-11-23 10:10:54'),
(159, 'Menambahkan data peminjaman baru dengan ISBN 8807', '2024-11-23 10:11:20'),
(160, 'Pengembalian buku dengan ID Peminjam 65', '2024-11-23 10:49:28'),
(161, 'Pengembalian buku dengan ID Peminjam 70', '2024-11-23 13:02:10'),
(162, 'Pengembalian buku dengan ID Peminjam 70', '2024-11-23 13:02:36'),
(163, 'Menghapus pengembalian dengan id pengembalian : 66', '2024-11-23 13:13:53'),
(164, 'Menambahkan data buku baru dengan ISBN 67373', '2024-11-23 13:55:46'),
(165, 'Memperbarui data anggota dengan NIM 203039393', '2024-11-23 13:56:27'),
(166, 'Menambahkan data peminjaman baru dengan ISBN 8799', '2024-11-23 13:57:35'),
(167, 'Pengembalian buku dengan ID Peminjam 69', '2024-11-23 14:20:21'),
(168, 'Pengembalian buku dengan ID Peminjam 67', '2024-11-23 15:56:25');

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_anggota`
--

CREATE TABLE `t_anggota` (
  `id_anggota` int(11) NOT NULL,
  `nim` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `prodi` varchar(50) NOT NULL,
  `fakultas` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `t_anggota`
--

INSERT INTO `t_anggota` (`id_anggota`, `nim`, `nama`, `prodi`, `fakultas`) VALUES
(23, '230441100178', 'anna', 'Ilmu Hukum', 'Fakultas Hukum'),
(24, '230441100200', 'putri', 'Teknik Mesin', 'Fakultas Teknik'),
(25, '230441100201', 'rani', 'Antropologi', 'Fakultas Ilmu Sosial dan Ilmu Budaya'),
(26, '230441100204', 'dita', 'Pendidikan Bahasa', 'Fakultas Ilmu Pendidikan'),
(27, '230441100207', 'tina', 'Studi Islam', 'Fakultas Keislaman'),
(28, '230111938872', 'nisa', 'Sosiologi', 'Fakultas Ilmu Sosial dan Ilmu Budaya'),
(29, '272727728282', 'amalia', 'Syariah', 'Fakultas Keislaman'),
(30, '23049494939', 'fitri', 'Teknik Sipil', 'Fakultas Teknik'),
(31, '23874848484', 'lestari', 'Agribisnis', 'Fakultas Pertanian'),
(32, '3489348348934', 'berlanda', 'Studi Islam', 'Fakultas Keislaman'),
(33, '2892892892', 'gultom', 'Antropologi', 'Fakultas Ilmu Sosial dan Ilmu Budaya'),
(34, '203039393', 'siapa kamu', 'Agribisnis', 'Fakultas Pertanian');

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_buku`
--

CREATE TABLE `t_buku` (
  `isbn` varchar(30) NOT NULL,
  `judul_buku` varchar(100) NOT NULL,
  `penulis` varchar(100) NOT NULL,
  `tahun_terbit` int(4) DEFAULT NULL,
  `jenis_buku` varchar(30) DEFAULT NULL,
  `penerbit` varchar(30) NOT NULL,
  `stok` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `t_buku`
--

INSERT INTO `t_buku` (`isbn`, `judul_buku`, `penulis`, `tahun_terbit`, `jenis_buku`, `penerbit`, `stok`) VALUES
('48484', 'Komputer', 'Rian Januari', 2009, 'Pelajaran', 'Informatika', 1),
('4553', 'Malin Kundang', 'dodi', 1992, 'dongeng', 'gramedia', 34),
('5758', 'Doa Ibu', 'Malin', 2008, 'Dongengg', 'Dunia Buku', 3),
('5758', 'Doa Ibu', 'Malin', 2008, 'Dongengg', 'Dunia Buku', 3),
('8788', 'Pancasila ', 'Hadi', 2011, 'Pelajaran', 'Gramedia', 7),
('8789', 'Dunia Imajinasi', 'Yunus', 2019, 'Novel', 'Dunia Buku', 4),
('8790', 'Kesunyian Malam', 'Nanda Amalia', 2010, 'Novel', 'Dunia Buku', 7),
('8791', 'Bandung 2001', 'Silmia NF', 2001, 'Novel', 'Dunia Buku', 10),
('8792', 'Tips Lancar UN', 'Rian Januari', 2021, 'Pelajaran', 'Dunia Buku', 9),
('8793', 'Nasib Anak', 'Yunus', 2000, 'Fiksi', 'Dunia Buku', 3),
('8794', 'Matematika ', 'Amri Irawan', 2010, 'Pelajaran', 'Gramedia', 2),
('8795', 'PemWeb', 'Jajang Nurjaman', 2013, 'Ilmu Komputer', 'Gramedia', 11),
('8796', 'Java Pemula', 'Jajang Nurjaman', 2017, 'Ilmu Komputer', 'Gramedia', 4),
('8797', 'Hidup Sehat', 'Yunus', 2018, 'Novel', 'Dunia Buku', 5),
('8798', 'JarKom', 'Agus Setiadi', 2019, 'Ilmu Komputer', 'Gramedia', 3),
('8799', 'Terbit Dari Timur', 'Yunus', 2019, 'Novel', 'Dunia Buku', 7),
('8800', 'Membosankan', 'Nanda Amalia', 2019, 'Novel', 'Dunia Buku', 5),
('8801', 'MatDas', 'Amri Irawan', 2000, 'Pelajaran', 'Gramedia', 5),
('8802', 'MatDas 2', 'Amri Irawan', 2019, 'Pelajaran', 'Gramedia', 4),
('8803', 'MatDas 3', 'Amri Irawan', 2020, 'Pelajaran', 'Gramedia', 5),
('8804', 'Kalkulus 2', 'Neti', 2000, 'Pelajaran', 'Gramedia', 10),
('8805', 'Manajemen', 'Rian Januari', 2011, 'Ilmu Komputer', 'Informatika', 7),
('8806', 'Menyelamtkanmu', 'Nanda Amalia', 2000, 'Novel', 'Dunia Buku', 13),
('8807', 'Memikirkanmu', 'Nanda Amalia', 2019, 'Novel', 'Juragan21', 55),
('8808', 'Tips Olahraga', 'Malin', 2000, 'Pelajaran', 'Gramedia', 9),
('8809', 'Teknik Industri', 'Jajang Nurjaman', 1999, 'Ilmu Komputer', 'Gramedia', 6),
('3646464333', 'apacoba', 'sss', 3003, 'dddd', 'dds', 57),
('222', 'c', 'c', 2020, 'cc', 'x', 4),
('67373', 'saya', 'kamu', 2023, 'terserah', 'dia', 3);

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_kembali`
--

CREATE TABLE `t_kembali` (
  `id_pengembalian` int(11) NOT NULL,
  `id_peminjaman` int(11) NOT NULL,
  `tgl_mengembalikan` date DEFAULT NULL,
  `denda` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `t_kembali`
--

INSERT INTO `t_kembali` (`id_pengembalian`, `id_peminjaman`, `tgl_mengembalikan`, `denda`) VALUES
(23, 65, '2024-11-23', 0),
(24, 67, '2024-11-23', 0),
(25, 65, '2024-11-23', 0),
(26, 70, '2024-11-23', 0),
(27, 70, '2024-11-23', 0),
(28, 69, '2024-11-23', 0),
(29, 67, '2024-11-23', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_petugas`
--

CREATE TABLE `t_petugas` (
  `id_petugas` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `t_petugas`
--

INSERT INTO `t_petugas` (`id_petugas`, `username`, `password`, `nama`, `email`) VALUES
(1, 'admin', 'admin', NULL, NULL),
(3, 'naa', 'naa', 'nasa', 'anna@milo.bom'),
(4, 'anna', 'anna', 'anna', 'annaa@email.com');

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_pinjam`
--

CREATE TABLE `t_pinjam` (
  `id_peminjaman` int(11) NOT NULL,
  `id_anggota` int(11) DEFAULT NULL,
  `isbn` varchar(30) NOT NULL,
  `tgl_pinjam` date DEFAULT NULL,
  `tgl_kembali` date DEFAULT NULL,
  `jumlah_buku` int(11) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Sedang dipinjam'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `t_pinjam`
--

INSERT INTO `t_pinjam` (`id_peminjaman`, `id_anggota`, `isbn`, `tgl_pinjam`, `tgl_kembali`, `jumlah_buku`, `status`) VALUES
(65, 26, '8790', '2024-11-23', '2024-11-30', 1, 'Sudah Dikembalikan'),
(67, 24, '8808', '2024-11-23', '2024-11-30', 1, 'Sudah Dikembalikan'),
(68, 23, '8809', '2024-11-23', '2024-11-30', 1, 'Sedang dipinjam'),
(69, 28, '8807', '2024-11-23', '2024-11-30', 1, 'Sedang dipinjam'),
(70, 29, '8807', '2024-11-25', '2024-12-02', 1, 'Sudah Dikembalikan'),
(71, 29, '8799', '2024-11-23', '2024-11-30', 2, 'Sedang dipinjam');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `t_aktivitas`
--
ALTER TABLE `t_aktivitas`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `t_anggota`
--
ALTER TABLE `t_anggota`
  ADD PRIMARY KEY (`id_anggota`);

--
-- Indeks untuk tabel `t_kembali`
--
ALTER TABLE `t_kembali`
  ADD PRIMARY KEY (`id_pengembalian`);

--
-- Indeks untuk tabel `t_petugas`
--
ALTER TABLE `t_petugas`
  ADD PRIMARY KEY (`id_petugas`),
  ADD UNIQUE KEY `unique_email` (`email`);

--
-- Indeks untuk tabel `t_pinjam`
--
ALTER TABLE `t_pinjam`
  ADD PRIMARY KEY (`id_peminjaman`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `t_aktivitas`
--
ALTER TABLE `t_aktivitas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=169;

--
-- AUTO_INCREMENT untuk tabel `t_anggota`
--
ALTER TABLE `t_anggota`
  MODIFY `id_anggota` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT untuk tabel `t_kembali`
--
ALTER TABLE `t_kembali`
  MODIFY `id_pengembalian` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT untuk tabel `t_petugas`
--
ALTER TABLE `t_petugas`
  MODIFY `id_petugas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `t_pinjam`
--
ALTER TABLE `t_pinjam`
  MODIFY `id_peminjaman` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
