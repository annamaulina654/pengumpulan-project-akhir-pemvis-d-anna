package Data;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import perpus.KoneksiDatabase;


public class dashboard {
    private String jmlBuku, jmlAnggota, jmlPinjam, jmlKembali, jmlAktivitas;
    Connection conn = KoneksiDatabase.getConnection();

    
    public String getJmlBuku(){
        return jmlBuku;
    }
    
    public String getJmlAnggota(){
        return jmlAnggota;
    }
    
    public String getJmlPinjam(){
        return jmlPinjam;
    }
    
    public String getJmlKembali(){
        return jmlKembali;
    }
    
    public String getJmlAktivitas(){
        return jmlAktivitas;
    }
    
    public void jumlahBuku(){
        try {
            String sql = "SELECT count(*) AS jumlah FROM t_buku";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet hasil = ps.executeQuery();
            while (hasil.next()) {
               jmlBuku = hasil.getString("jumlah");
           }
        }catch(SQLException e){
            
        }
    }
    
    public void jumlahAnggota(){
        try {
            String sql = "SELECT count(*) AS jumlah FROM t_anggota";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet hasil = ps.executeQuery();
        
           while(hasil.next()){
               jmlAnggota = hasil.getString("jumlah");
           }
        }catch(SQLException e){
            
        }
    }
    
    public void jumlahPinjam(){
        try {
            String sql = "SELECT count(*) AS jumlah FROM t_pinjam WHERE tgl_pinjam=curdate()";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet hasil = ps.executeQuery();
        
           while(hasil.next()){
               jmlPinjam = hasil.getString("jumlah");
           }
        }catch(SQLException e){
            
        }
    }
    
    public void jumlahKembali(){
        try {
            String sql = "SELECT count(*) AS jumlah FROM t_kembali WHERE tgl_mengembalikan=curdate()";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet hasil = ps.executeQuery();

           while(hasil.next()){
               jmlKembali = hasil.getString("jumlah");
           }
        }catch(SQLException e){
            
        }
    }
    
    public void jumlahAktifitas(){
        try {
            String sql = "SELECT count(*) AS jumlah FROM t_aktivitas WHERE DATE(tglWaktu)=curdate()";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet hasil = ps.executeQuery();

           while(hasil.next()){
               jmlAktivitas = hasil.getString("jumlah");
           }
        }catch(SQLException e){
            
        }
    }
}
