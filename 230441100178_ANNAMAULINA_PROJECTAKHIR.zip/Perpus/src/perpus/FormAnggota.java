package perpus;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;

public class FormAnggota extends javax.swing.JInternalFrame {

    Connection conn;
    NewJFrame parentFrame;
    private boolean isEditMode = false;  
    private final Map<String, String[]> dataProdi = Map.of(
        "Fakultas Hukum", new String[]{"Ilmu Hukum"},
        "Fakultas Teknik", new String[]{"Teknik Sipil", "Teknik Mesin", "Teknik Elektro"},
        "Fakultas Pertanian", new String[]{"Agronomi", "Agribisnis"},
        "Fakultas Ilmu Pendidikan", new String[]{"Pendidikan Bahasa", "Pendidikan Matematika"},
        "Fakultas Ilmu Sosial dan Ilmu Budaya", new String[]{"Sosiologi", "Antropologi"},
        "Fakultas Keislaman", new String[]{"Studi Islam", "Syariah"},
        "Fakultas Ekonomi dan Bisnis", new String[]{"Manajemen", "Akuntansi"}
    );

    public FormAnggota(NewJFrame parentFrame) {
        initComponents();
        conn = KoneksiDatabase.getConnection();
        this.parentFrame = parentFrame;
        tfId.setVisible(false);
        lblId.setVisible(false);
        cbFakultas.setSelectedIndex(0);
        cbProdi.setModel(new DefaultComboBoxModel<>(dataProdi.get(cbFakultas.getSelectedItem())));
    }
    
    private void saveData() {
        if (tfNim.getText().trim().isEmpty() || 
                tfNama.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(parentFrame, "Harap isi semua field!",
                    "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String nim = tfNim.getText().trim();
        if (!nim.matches("\\d+")) { // Regex untuk angka saja
            JOptionPane.showMessageDialog(parentFrame, "NIM harus berupa angka yang valid.",
                    "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // Cek apakah NIM sudah ada di database
            String checkSql = "SELECT COUNT(*) AS jumlah FROM t_anggota WHERE nim = ? AND id_anggota != ?";
            PreparedStatement checkPs = conn.prepareStatement(checkSql);
            checkPs.setString(1, tfNim.getText());
            checkPs.setString(2, isEditMode ? tfId.getText() : "0"); // Exclude current ID jika mode edit
            ResultSet rs = checkPs.executeQuery();
            if (rs.next() && rs.getInt("jumlah") > 0) {
                JOptionPane.showMessageDialog(parentFrame, "NIM sudah tersedia. Harap gunakan NIM lain.",
                        "Duplicate Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String sql;
            if (isEditMode) {
                // Query untuk update data jika dalam mode edit
                sql = "UPDATE t_anggota SET nim = ?, nama = ?, prodi = ?, fakultas = ? WHERE id_anggota = ?";
            } else {
                // Query untuk tambah data baru
                sql = "INSERT INTO t_anggota (nim, nama, prodi, fakultas) VALUES (?, ?, ?, ?)";
            }

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, tfNim.getText());
            ps.setString(2, tfNama.getText());
            ps.setString(3, (String) cbProdi.getSelectedItem());
            ps.setString(4, (String) cbFakultas.getSelectedItem());

            if (isEditMode) {
                ps.setString(5, tfId.getText()); 
            }

            ps.executeUpdate();
            JOptionPane.showMessageDialog(parentFrame, isEditMode ? "Data berhasil diperbarui" : "Data berhasil disimpan");

            parentFrame.loadDataAnggota(); // Refresh data di frame utama
            parentFrame.tampilDataDashboard();
            String param = isEditMode ? ("Memperbarui data anggota dengan NIM " + tfNim.getText() ) :
                    ("Menambahkan data anggota baru dengan NIM " + tfNim.getText() );
            parentFrame.simpanAktivitas(param);
            parentFrame.loadDataAktivitas();
            this.dispose(); // Tutup form

        } catch (SQLException e) {
            System.out.println("Error Save Data: " + e.getMessage());
            JOptionPane.showMessageDialog(parentFrame, "Error saving data. Please try again.",
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

        
    public void setDataForEdit(String id, String nim, String nama, String prodi, String fakultas) {
        isEditMode = true;  // Mengaktifkan mode edit
        tfId.setText(id);
        tfNim.setText(nim);
        tfNama.setText(nama);
        cbFakultas.setSelectedItem(fakultas);
        cbProdi.setModel(new DefaultComboBoxModel<>(dataProdi.get(fakultas)));
        cbProdi.setSelectedItem(prodi);
        btnSaveInternal.setText("Update");
    }
        
    private void resetForm() {
        tfId.setText(""); // Kosongkan field ID
        tfNim.setText(""); // Kosongkan field NIM
        tfNama.setText(""); // Kosongkan field Nama
        cbFakultas.setSelectedIndex(0); // Kembali ke pilihan pertama pada ComboBox Fakultas
        cbProdi.setModel(new DefaultComboBoxModel<>(new String[]{})); // Kosongkan model ComboBox Prodi
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jPanel3 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        tfNim = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        tfNama = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        Fakultas = new javax.swing.JLabel();
        btnSaveInternal = new javax.swing.JButton();
        lblId = new javax.swing.JLabel();
        tfId = new javax.swing.JTextField();
        cbFakultas = new javax.swing.JComboBox<>();
        cbProdi = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jPanel2.setBackground(new java.awt.Color(249, 247, 201));
        java.awt.GridBagLayout jPanel2Layout = new java.awt.GridBagLayout();
        jPanel2Layout.columnWidths = new int[] {0, 29, 0, 29, 0, 29, 0, 29, 0};
        jPanel2Layout.rowHeights = new int[] {0, 13, 0, 13, 0, 13, 0, 13, 0, 13, 0};
        jPanel2.setLayout(jPanel2Layout);

        jLabel1.setText("NIM");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel2.add(jLabel1, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 0.1;
        jPanel2.add(tfNim, gridBagConstraints);

        jLabel2.setText("Nama");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel2.add(jLabel2, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 0.1;
        jPanel2.add(tfNama, gridBagConstraints);

        jLabel3.setText("Prodi");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel2.add(jLabel3, gridBagConstraints);

        Fakultas.setText("Fakultas");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel2.add(Fakultas, gridBagConstraints);

        btnSaveInternal.setText("Save");
        btnSaveInternal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveInternalActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 10;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel2.add(btnSaveInternal, gridBagConstraints);

        lblId.setText("ID Anggota");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel2.add(lblId, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel2.add(tfId, gridBagConstraints);

        cbFakultas.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Fakultas Hukum", "Fakultas Teknik", "Fakultas Pertanian", "Fakultas Ilmu Pendidikan", "Fakultas Ilmu Sosial dan Ilmu Budaya", "Fakultas Keislaman", "Fakultas Ekonomi dan Bisnis" }));
        cbFakultas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbFakultasActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 6;
        jPanel2.add(cbFakultas, gridBagConstraints);

        cbProdi.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbProdi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbProdiActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel2.add(cbProdi, gridBagConstraints);

        jButton1.setText("Batal");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 10;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_END;
        jPanel2.add(jButton1, gridBagConstraints);

        jButton2.setText("Reset");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 10;
        jPanel2.add(jButton2, gridBagConstraints);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 249, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSaveInternalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveInternalActionPerformed
        // TODO add your handling code here:
        saveData();

    }//GEN-LAST:event_btnSaveInternalActionPerformed

    private void cbProdiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbProdiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbProdiActionPerformed

    private void cbFakultasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbFakultasActionPerformed
        // TODO add your handling code here:
        String selectedFakultas = (String) cbFakultas.getSelectedItem();
        if (selectedFakultas != null) {
            cbProdi.setModel(new DefaultComboBoxModel<>(dataProdi.get(selectedFakultas)));
        }
    }//GEN-LAST:event_cbFakultasActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        resetForm();
    }//GEN-LAST:event_jButton2ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Fakultas;
    private javax.swing.JButton btnSaveInternal;
    private javax.swing.JComboBox<String> cbFakultas;
    private javax.swing.JComboBox<String> cbProdi;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel lblId;
    private javax.swing.JTextField tfId;
    private javax.swing.JTextField tfNama;
    private javax.swing.JTextField tfNim;
    // End of variables declaration//GEN-END:variables
}
