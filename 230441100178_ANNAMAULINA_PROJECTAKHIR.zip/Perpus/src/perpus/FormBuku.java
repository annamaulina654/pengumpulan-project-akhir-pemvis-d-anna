package perpus;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class FormBuku extends javax.swing.JInternalFrame {
    Connection conn;
    NewJFrame parentFrame;
    private boolean isEditMode = false;  // Tambahkan variabel untuk mendeteksi mode edit
    private String originalIsbn = ""; // Menyimpan ISBN asli untuk query update

    public FormBuku(NewJFrame parentFrame) {
        initComponents();
        conn = KoneksiDatabase.getConnection();
        this.parentFrame = parentFrame;
    }
    
    private void saveData() {
        if (tfIsbn.getText().trim().isEmpty() || 
                tfJudul.getText().trim().isEmpty() || 
                tfPenulis.getText().trim().isEmpty() || 
                tfJenis.getText().trim().isEmpty() || 
                tfPenerbit.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(parentFrame, "Harap isi semua field!",
                "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validasi ISBN agar hanya berupa angka
        try {
            Integer.parseInt(tfIsbn.getText().trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(parentFrame, "ISBN harus berupa angka yang valid.",
                    "Invalid ISBN", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validasi jumlah stok
        try {
            int stok = Integer.parseInt(tfStok.getText().trim());
            if (stok <= 0) {
                JOptionPane.showMessageDialog(parentFrame, "Stok harus berupa angka lebih dari 0.",
                        "Invalid Stock", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(parentFrame, "Stok harus berupa angka yang valid.",
                    "Invalid Stock", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!isEditMode) { 
            try {
                String checkSql = "SELECT COUNT(*) FROM t_buku WHERE isbn = ?";
                PreparedStatement checkPs = conn.prepareStatement(checkSql);
                checkPs.setString(1, tfIsbn.getText());
                ResultSet rs = checkPs.executeQuery();
                if (rs.next() && rs.getInt(1) > 0) {
                    JOptionPane.showMessageDialog(parentFrame, "ISBN sudah tersedia. Gunakan ISBN yang lain.",
                            "Duplicate ISBN Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            } catch (SQLException e) {
                System.out.println("Error checking ISBN: " + e.getMessage());
                JOptionPane.showMessageDialog(parentFrame, "Error checking ISBN. Please try again.",
                        "Database Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        try {
            String sql;
            if (isEditMode) {
                sql = "UPDATE t_buku SET isbn = ?, judul_buku = ?, penulis = ?, tahun_terbit = ?, jenis_buku = ?, penerbit = ?, stok = ? WHERE isbn = ?";
            } else {
                sql = "INSERT INTO t_buku (isbn, judul_buku, penulis, tahun_terbit, jenis_buku, penerbit, stok) VALUES (?, ?, ?, ?, ?, ?, ?)";
            }

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, tfIsbn.getText());
            ps.setString(2, tfJudul.getText());
            ps.setString(3, tfPenulis.getText());
            ps.setInt(4, yearChooser.getYear());
            ps.setString(5, tfJenis.getText());
            ps.setString(6, tfPenerbit.getText());
            ps.setString(7, tfStok.getText());

            if (isEditMode) {
                ps.setString(8, originalIsbn); // ISBN asli sebagai syarat update
            }

            ps.executeUpdate();
            JOptionPane.showMessageDialog(parentFrame, isEditMode ? "Data berhasil diperbarui" : "Data berhasil disimpan");

            parentFrame.loadData(); // Refresh data di frame utama
            parentFrame.tampilDataDashboard();
            String param = isEditMode ? ("Memperbarui data buku dengan ISBN " + tfIsbn.getText()) :
                    ("Menambahkan data buku baru dengan ISBN " + tfIsbn.getText());
            parentFrame.simpanAktivitas(param);
            parentFrame.loadDataAktivitas();
            this.dispose(); // Tutup form

        } catch (SQLException e) {
            System.out.println("Error Save Data: " + e.getMessage());
            JOptionPane.showMessageDialog(parentFrame, "Error saving data. Please try again.",
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
 
    public void setDataForEdit(String isbn, String judul, String penulis, int tahun, String jenis, String penerbit, String stok) {
        isEditMode = true;  // Mengaktifkan mode edit
        originalIsbn = isbn;
        tfIsbn.setText(isbn);
        tfJudul.setText(judul);
        tfPenulis.setText(penulis);
        yearChooser.setYear(tahun);
        tfJenis.setText(jenis);
        tfPenerbit.setText(penerbit);
        tfStok.setText(stok);
        btnSaveInternal.setText("Update");
    }
        
        public void resetForm() {
            tfIsbn.setText(""); // Kosongkan field ISBN
            tfJudul.setText(""); // Kosongkan field Judul
            tfPenulis.setText(""); // Kosongkan field Penulis
            yearChooser.setYear(java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)); // Set tahun ke tahun sekarang
            tfJenis.setText(""); // Kosongkan field Jenis
            tfPenerbit.setText(""); // Kosongkan field Penerbit
            tfStok.setText(""); // Kosongkan field Stok
        }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        tfIsbn = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        tfJudul = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        tfPenulis = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        tfJenis = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        tfPenerbit = new javax.swing.JTextField();
        btnSaveInternal = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        tfStok = new javax.swing.JTextField();
        yearChooser = new com.toedter.calendar.JYearChooser();
        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        jPanel1.setBackground(new java.awt.Color(249, 247, 201));
        java.awt.GridBagLayout jPanel1Layout = new java.awt.GridBagLayout();
        jPanel1Layout.columnWidths = new int[] {0, 30, 0, 30, 0, 30, 0, 30, 0};
        jPanel1Layout.rowHeights = new int[] {0, 13, 0, 13, 0, 13, 0, 13, 0, 13, 0, 13, 0, 13, 0, 13, 0};
        jPanel1.setLayout(jPanel1Layout);

        jLabel1.setText("ISBN");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel1.add(jLabel1, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 0.1;
        jPanel1.add(tfIsbn, gridBagConstraints);

        jLabel2.setText("Judul Buku");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel1.add(jLabel2, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 0.1;
        jPanel1.add(tfJudul, gridBagConstraints);

        jLabel3.setText("Penulis");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel1.add(jLabel3, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 0.1;
        jPanel1.add(tfPenulis, gridBagConstraints);

        jLabel4.setText("Tahun Terbit");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel1.add(jLabel4, gridBagConstraints);

        jLabel5.setText("Jenis Buku");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 10;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel1.add(jLabel5, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 10;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 0.1;
        jPanel1.add(tfJenis, gridBagConstraints);

        jLabel6.setText("Penerbit");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 12;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel1.add(jLabel6, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 12;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 0.1;
        jPanel1.add(tfPenerbit, gridBagConstraints);

        btnSaveInternal.setText("Save");
        btnSaveInternal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveInternalActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 16;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_END;
        jPanel1.add(btnSaveInternal, gridBagConstraints);

        jLabel7.setText("Stok");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 14;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel1.add(jLabel7, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 14;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel1.add(tfStok, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel1.add(yearChooser, gridBagConstraints);

        jButton2.setText("Reset");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 16;
        jPanel1.add(jButton2, gridBagConstraints);

        jButton1.setText("Batal");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 6;
        gridBagConstraints.gridy = 16;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_END;
        jPanel1.add(jButton1, gridBagConstraints);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 399, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSaveInternalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveInternalActionPerformed
        // TODO add your handling code here:
        saveData();
        
    }//GEN-LAST:event_btnSaveInternalActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        resetForm();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSaveInternal;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField tfIsbn;
    private javax.swing.JTextField tfJenis;
    private javax.swing.JTextField tfJudul;
    private javax.swing.JTextField tfPenerbit;
    private javax.swing.JTextField tfPenulis;
    private javax.swing.JTextField tfStok;
    private com.toedter.calendar.JYearChooser yearChooser;
    // End of variables declaration//GEN-END:variables
}
