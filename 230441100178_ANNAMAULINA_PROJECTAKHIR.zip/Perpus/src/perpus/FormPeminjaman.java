
package perpus;

import com.toedter.calendar.JDateChooser;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class FormPeminjaman extends javax.swing.JInternalFrame {
    Connection conn;
    NewJFrame parentFrame;
    java.util.Date today = new java.util.Date();
    private boolean isEditMode = false; 
    
    public FormPeminjaman(NewJFrame parentFrame) {
        initComponents();
        conn = KoneksiDatabase.getConnection();
        this.parentFrame = parentFrame;
        lblPinjam.setVisible(false);
        tfIdPeminjaman.setVisible(false);
        loadCombo();
        tglKembali.setEditable(false);
        tglPinjam.setMaxSelectableDate(today);
    }
    
    private void loadCombo() {
        comboAnggota.removeAllItems();
        try {
            String sql = "SELECT * FROM t_anggota";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet hasil = ps.executeQuery();
            while (hasil.next()) {
                String id = hasil.getString("id_anggota");
                String nim = hasil.getString("nim");
                String nama = hasil.getString("nama");
                String gabung = id + " - " + nim + " - " + nama;
                comboAnggota.addItem(gabung);
            }
        } catch (SQLException e) {
           System.out.println("Error Save Data" + e.getMessage());
        }
        
        comboBuku.removeAllItems();
        try {
            String sql = "SELECT * FROM t_buku";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet hasil = ps.executeQuery();
            while (hasil.next()) {
                String isbn = hasil.getString("isbn");
                String judul = hasil.getString("judul_buku");
                String gabung = isbn + " - " + judul;
                comboBuku.addItem(gabung);
            }
        } catch (SQLException e) {
           System.out.println("Error Save Data" + e.getMessage());
        }
        
    }

    private void saveData() {
        if (comboAnggota.getSelectedIndex() == -1 || comboBuku.getSelectedIndex() == -1 || 
                tglPinjam.getDate() == null) {
            JOptionPane.showMessageDialog(parentFrame, "Harap isi semua field!",
                    "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }


        try {
            // Ambil ID Anggota dan ISBN dari combo box
            String selectedAnggota = (String) comboAnggota.getSelectedItem();
            String selectedBuku = (String) comboBuku.getSelectedItem();

            // Parsing ID Anggota (NIM) dan ISBN
            String idAnggota = selectedAnggota.split(" - ")[0]; // NIM
            String isbn = selectedBuku.split(" - ")[0]; // ISBN

            int jumlah = (int) jumlahBuku.getValue();
                    if (jumlah <= 0) {
                JOptionPane.showMessageDialog(parentFrame, "Jumlah buku tidak boleh 0 atau kurang dari 0.",
                        "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Format tanggal menjadi String
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String tgl = sdf.format(tglPinjam.getDate());
            String tglKembaliStr = tglKembali.getText();

            String checkStokSql = "SELECT stok FROM t_buku WHERE isbn = ?";
            PreparedStatement psCheckStok = conn.prepareStatement(checkStokSql);
            psCheckStok.setString(1, isbn);
            ResultSet rs = psCheckStok.executeQuery();
            if (rs.next()) {
                int stokBuku = rs.getInt("stok");
                if (stokBuku < jumlah) {
                    JOptionPane.showMessageDialog(parentFrame, "Stok buku tidak cukup", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }

            // Update stok buku setelah peminjaman
            String updateStokSql = "UPDATE t_buku SET stok = stok - ? WHERE isbn = ?";
            PreparedStatement psUpdateStok = conn.prepareStatement(updateStokSql);
            psUpdateStok.setInt(1, jumlah);
            psUpdateStok.setString(2, isbn);
            psUpdateStok.executeUpdate();

            String sql;
            PreparedStatement ps;

            if (isEditMode) {
                // Query untuk update data peminjaman jika dalam mode edit
                sql = "UPDATE t_pinjam SET id_anggota = ?, isbn = ?, tgl_pinjam = ?, tgl_kembali = ?, jumlah_buku = ? WHERE id_peminjaman = ?";
                ps = conn.prepareStatement(sql);
                ps.setString(1, idAnggota);
                ps.setString(2, isbn);
                ps.setString(3, tgl);
                ps.setString(4, tglKembaliStr);
                ps.setInt(5, jumlah);
                ps.setInt(6, Integer.parseInt(tfIdPeminjaman.getText())); // Assuming you have a text field for the ID of the record to edit
            } else {
                // Query untuk tambah data baru
                sql = "INSERT INTO t_pinjam (id_anggota, isbn, tgl_pinjam, tgl_kembali, jumlah_buku) VALUES (?, ?, ?, ?, ?)";
                ps = conn.prepareStatement(sql);
                ps.setString(1, idAnggota);
                ps.setString(2, isbn);
                ps.setString(3, tgl);
                ps.setString(4, tglKembaliStr);
                ps.setInt(5, jumlah);
            }

            ps.executeUpdate();
            JOptionPane.showMessageDialog(parentFrame, isEditMode ? "Data berhasil diperbarui" : "Data berhasil disimpan");

            parentFrame.loadData();
            parentFrame.loadDataPeminjaman();
            parentFrame.tampilDataDashboard();
            String param = isEditMode ? ("Memperbarui data peminjaman dengan ISBN " + isbn) :
                    ("Menambahkan data peminjaman baru dengan ISBN " + isbn);
            parentFrame.simpanAktivitas(param);
            parentFrame.loadDataAktivitas();
            this.dispose(); // Tutup form

        } catch (SQLException e) {
            System.out.println("Error Save Data: " + e.getMessage());
            JOptionPane.showMessageDialog(parentFrame, "Error saving data. Please try again.",
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void setDataForEdit(int idPeminjaman, String anggota, String buku, String tglPinjamStr, String tglKembaliStr, int jumlahBuku) {
        isEditMode = true; // Enable edit mode
        tfIdPeminjaman.setText(String.valueOf(idPeminjaman));
        comboAnggota.setSelectedItem(anggota);
        comboBuku.setSelectedItem(buku);

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

            if (tglPinjam instanceof JDateChooser) {
                tglPinjam.setDate(sdf.parse(tglPinjamStr));
            }

            if (tglKembali instanceof JTextField) {
                tglKembali.setText(tglKembaliStr);
            }
        } catch (ParseException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(parentFrame, "Error parsing date. Please check the format.",
                    "Date Error", JOptionPane.ERROR_MESSAGE);
        }

        this.jumlahBuku.setValue(jumlahBuku);
        btnSaveInternal.setText("Update"); // Change button text to "Update"
    }

    private void resetForm() {
        comboAnggota.setSelectedIndex(0);
        comboBuku.setSelectedIndex(0);

        // Reset tanggal pinjam
        if (tglPinjam instanceof com.toedter.calendar.JDateChooser) {
            tglPinjam.setDate(null); // Set JDateChooser to null
        }

        // Reset tanggal kembali
        if (tglKembali instanceof javax.swing.JTextField) {
            tglKembali.setText(""); // Clear JTextField
        }

        jumlahBuku.setValue(1); 
        tfIdPeminjaman.setText("");

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jPanel2 = new javax.swing.JPanel();
        lblPinjam = new javax.swing.JLabel();
        tfIdPeminjaman = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnSaveInternal = new javax.swing.JButton();
        tglPinjam = new com.toedter.calendar.JDateChooser();
        comboAnggota = new javax.swing.JComboBox<>();
        comboBuku = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jumlahBuku = new javax.swing.JSpinner();
        tglKembali = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        jPanel2.setBackground(new java.awt.Color(249, 247, 201));
        java.awt.GridBagLayout jPanel2Layout = new java.awt.GridBagLayout();
        jPanel2Layout.columnWidths = new int[] {0, 66, 0, 66, 0};
        jPanel2Layout.rowHeights = new int[] {0, 13, 0, 13, 0, 13, 0, 13, 0, 13, 0, 13, 0};
        jPanel2.setLayout(jPanel2Layout);

        lblPinjam.setText("ID Peminjaman");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel2.add(lblPinjam, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 0.1;
        jPanel2.add(tfIdPeminjaman, gridBagConstraints);

        jLabel2.setText("Anggota");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel2.add(jLabel2, gridBagConstraints);

        jLabel3.setText("Buku");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel2.add(jLabel3, gridBagConstraints);

        jLabel4.setText("Tanggal Pinjam");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel2.add(jLabel4, gridBagConstraints);

        btnSaveInternal.setText("Save");
        btnSaveInternal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveInternalActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 12;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel2.add(btnSaveInternal, gridBagConstraints);

        tglPinjam.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                tglPinjamPropertyChange(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel2.add(tglPinjam, gridBagConstraints);

        comboAnggota.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel2.add(comboAnggota, gridBagConstraints);

        comboBuku.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel2.add(comboBuku, gridBagConstraints);

        jLabel1.setText("Tanggal Kembali");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel2.add(jLabel1, gridBagConstraints);

        jLabel5.setText("Jumlah");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 10;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel2.add(jLabel5, gridBagConstraints);

        jumlahBuku.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 10;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel2.add(jumlahBuku, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel2.add(tglKembali, gridBagConstraints);

        jButton1.setText("Batal");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 12;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_END;
        jPanel2.add(jButton1, gridBagConstraints);

        jButton2.setText("Reset");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 12;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel2.add(jButton2, gridBagConstraints);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 399, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSaveInternalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveInternalActionPerformed
        // TODO add your handling code here:
        saveData();
    }//GEN-LAST:event_btnSaveInternalActionPerformed

    private void tglPinjamPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_tglPinjamPropertyChange
        // TODO add your handling code here:
        if (tglPinjam.getDate() != null) {
            // Tambahkan 7 hari ke tanggal pinjam
            java.util.Date pinjamDate = tglPinjam.getDate();
            java.util.Calendar cal = java.util.Calendar.getInstance();
            cal.setTime(pinjamDate);
            cal.add(java.util.Calendar.DAY_OF_MONTH, 7); // Tambahkan 7 hari
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            tglKembali.setText(sdf.format(cal.getTime()));
        }
    }//GEN-LAST:event_tglPinjamPropertyChange

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        resetForm();
    }//GEN-LAST:event_jButton2ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSaveInternal;
    private javax.swing.JComboBox<String> comboAnggota;
    private javax.swing.JComboBox<String> comboBuku;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JSpinner jumlahBuku;
    private javax.swing.JLabel lblPinjam;
    private javax.swing.JTextField tfIdPeminjaman;
    private javax.swing.JTextField tglKembali;
    private com.toedter.calendar.JDateChooser tglPinjam;
    // End of variables declaration//GEN-END:variables
}
