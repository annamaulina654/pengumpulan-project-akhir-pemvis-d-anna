
package perpus;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;

public class FormPengembalian extends javax.swing.JInternalFrame {

    Connection conn;
    NewJFrame parentFrame;
    private boolean isEditMode = false;
    private int currentIdPengembalian = -1;
    java.util.Date today = new java.util.Date();

    public FormPengembalian(NewJFrame parentFrame) {
        initComponents();
        
        conn = KoneksiDatabase.getConnection();
        this.parentFrame = parentFrame;
        lblIdKembali.setVisible(false);
        tfIdPengembalian.setVisible(false);
        loadCombo();
             
        tglMengembalikan.setMinSelectableDate(today);
        tglPinjam.setEditable(false);
        tglKembali.setEditable(false);
        telat.setEditable(false);
        denda.setEditable(false);
    }
    
    private void loadCombo() {
        comboPeminjaman.removeAllItems();
        try {
            String sql = "SELECT * FROM t_pinjam WHERE status = 'Sedang dipinjam'";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet hasil = ps.executeQuery();
            while (hasil.next()) {
                String id = hasil.getString("id_peminjaman");
                parentFrame.loadDataPeminjaman();
                comboPeminjaman.addItem(id);
            }
        } catch (SQLException e) {
           System.out.println("Error Save Data" + e.getMessage());
        }
    }
    
    private void fillDates(String idPeminjaman) {
        try {
            String sql = "SELECT tgl_pinjam, tgl_kembali FROM t_pinjam WHERE id_peminjaman = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, idPeminjaman);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                String tglPinjamStr = rs.getString("tgl_pinjam");
                String tglKembaliStr = rs.getString("tgl_kembali");

                // Tampilkan tanggal sebagai teks di JTextField
                tglPinjam.setText(tglPinjamStr);
                tglKembali.setText(tglKembaliStr);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching dates: " + e.getMessage());
        }
    }
    
    private void calculateTelatAndDenda() {
        try {
            // Ambil tanggal kembali dari JTextField dan parsing
            String tglKembaliStr = tglKembali.getText();  // Ambil teks dari JTextField
            java.util.Date tanggalKembali = null;
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

            // Pastikan tanggal kembali tidak kosong dan valid
            if (tglKembaliStr != null && !tglKembaliStr.trim().isEmpty()) {
                tanggalKembali = sdf.parse(tglKembaliStr);  // Parsing tanggal
            } else {
                JOptionPane.showMessageDialog(parentFrame, "Tanggal Kembali tidak boleh kosong.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;  // Jika kosong, keluar dari metode
            }

            // Ambil tanggal mengembalikan dari JDateChooser
            java.util.Date tanggalMengembalikan = tglMengembalikan.getDate();  // Ambil tanggal dari JDateChooser

            // Periksa apakah tanggal mengembalikan kosong
            if (tanggalMengembalikan == null) {
                JOptionPane.showMessageDialog(parentFrame, "Tanggal Mengembalikan harus dipilih.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Hitung selisih hari
            long diffInMillies = tanggalMengembalikan.getTime() - tanggalKembali.getTime();
            long diffDays = diffInMillies / (24 * 60 * 60 * 1000);

            // Jika telat
            if (diffDays > 0) {
                telat.setText(String.valueOf(diffDays));
                int dendaAmount = (int) diffDays * 500;  // Denda Rp500 per hari
                denda.setText(String.valueOf(dendaAmount));
            } else {
                telat.setText("0");
                denda.setText("0");
            }
        } catch (ParseException e) {
            // Tangani pengecualian jika format tanggal salah
            JOptionPane.showMessageDialog(parentFrame, "Format tanggal Kembali tidak valid. Gunakan format YYYY-MM-DD.", "Format Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            // Tangani pengecualian umum
            System.out.println("Error calculating late fee: " + e.getMessage());
            JOptionPane.showMessageDialog(parentFrame, "Error calculating late fee. Please check the dates.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveData() {
        int jumlahBukuPinjam = 0;
        try {
            // Ambil jumlah buku yang dipinjam berdasarkan ID peminjaman
            String sqlFetchJumlah = "SELECT jumlah_buku FROM t_pinjam WHERE id_peminjaman = ?";
            PreparedStatement psFetchJumlah = conn.prepareStatement(sqlFetchJumlah);
            psFetchJumlah.setString(1, (String) comboPeminjaman.getSelectedItem());
            ResultSet rs = psFetchJumlah.executeQuery();
            if (rs.next()) {
                jumlahBukuPinjam = rs.getInt("jumlah_buku");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(parentFrame, "Gagal mengambil data jumlah buku.", "Database Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Ambil jumlah buku yang dikembalikan
        int jumlahDikembalikanValue = 0;
        try {
            jumlahDikembalikanValue = (int) jmlKembali.getValue();
            if (jumlahDikembalikanValue <= 0 || jumlahDikembalikanValue > jumlahBukuPinjam) {
                JOptionPane.showMessageDialog(parentFrame, "Jumlah buku dikembalikan harus lebih dari 0 dan tidak boleh melebihi jumlah buku yang dipinjam (" + jumlahBukuPinjam + ").", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(parentFrame, "Jumlah buku dikembalikan harus berupa angka.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validasi ID peminjaman dan tanggal mengembalikan
        if (comboPeminjaman.getSelectedIndex() == -1 || tglMengembalikan.getDate() == null) {
            JOptionPane.showMessageDialog(parentFrame, "ID Peminjaman dan Tanggal Mengembalikan harus diisi.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        int currentIdPengembalian = -1;
        try {
            // Ambil data dari input
            String selectedIdPeminjaman = (String) comboPeminjaman.getSelectedItem();
              // Gunakan getDate() untuk mengambil tanggal dari DateChooser
            java.util.Date tglMengembalikanDate = tglMengembalikan.getDate();

            // Format tanggal ke dalam format String yang sesuai dengan format di database
            String tglMengembalikanStr = new java.text.SimpleDateFormat("yyyy-MM-dd").format(tglMengembalikanDate);

            int telatDays = Integer.parseInt(telat.getText());
            int dendaAmount = Integer.parseInt(denda.getText());

            // Ambil ISBN dan jumlah buku dari peminjaman
            String isbn = "";
            int jumlahBuku = 0;
            String fetchDetailsSql = "SELECT isbn, jumlah_buku FROM t_pinjam WHERE id_peminjaman = ?";
            PreparedStatement psFetchDetails = conn.prepareStatement(fetchDetailsSql);
            psFetchDetails.setString(1, selectedIdPeminjaman);
            ResultSet rs = psFetchDetails.executeQuery();
            if (rs.next()) {
                isbn = rs.getString("isbn");
                jumlahBuku = rs.getInt("jumlah_buku");
            }

            if (isEditMode) {
                String updateSql = "UPDATE t_kembali SET id_peminjaman = ?, tgl_mengembalikan = ?, denda = ? WHERE id_pengembalian = ?";
                PreparedStatement ps = conn.prepareStatement(updateSql);
                ps.setString(1, selectedIdPeminjaman);
                ps.setString(2, tglMengembalikanStr);
                ps.setInt(3, dendaAmount);
                ps.setInt(4, currentIdPengembalian);
                ps.executeUpdate();

                JOptionPane.showMessageDialog(parentFrame, "Data pengembalian berhasil diperbarui!");
            } else {
                String insertSql = "INSERT INTO t_kembali (id_peminjaman, tgl_mengembalikan, denda) VALUES (?, ?, ?)";
                PreparedStatement ps = conn.prepareStatement(insertSql);
                ps.setString(1, selectedIdPeminjaman);
                ps.setString(2, tglMengembalikanStr);
                ps.setInt(3, dendaAmount);
                ps.executeUpdate();
                JOptionPane.showMessageDialog(parentFrame, "Data pengembalian berhasil disimpan!");
            }

            // Update stok buku
            String updateStokSql = "UPDATE t_buku SET stok = stok + ? WHERE isbn = ?";
            PreparedStatement psUpdateStok = conn.prepareStatement(updateStokSql);
            psUpdateStok.setInt(1, jumlahDikembalikanValue);
            psUpdateStok.setString(2, isbn);
            psUpdateStok.executeUpdate();

            // Update status atau jumlah buku di t_pinjam
            if (jumlahDikembalikanValue == jumlahBukuPinjam) {
                String updateStatusSql = "UPDATE t_pinjam SET status = 'Sudah Dikembalikan' WHERE id_peminjaman = ?";
                PreparedStatement psUpdateStatus = conn.prepareStatement(updateStatusSql);
                psUpdateStatus.setString(1, selectedIdPeminjaman);
                psUpdateStatus.executeUpdate();
            } else {
                String updateJumlahPinjamSql = "UPDATE t_pinjam SET jumlah_buku = jumlah_buku - ? WHERE id_peminjaman = ?";
                PreparedStatement psUpdateJumlahPinjam = conn.prepareStatement(updateJumlahPinjamSql);
                psUpdateJumlahPinjam.setInt(1, jumlahDikembalikanValue);
                psUpdateJumlahPinjam.setString(2, selectedIdPeminjaman);
                psUpdateJumlahPinjam.executeUpdate();
            }

            parentFrame.loadData();
            parentFrame.loadDataPengembalian();
            parentFrame.loadDataPeminjaman();
            parentFrame.tampilDataDashboard();
            parentFrame.simpanAktivitas("Pengembalian buku dengan ID Peminjam " + selectedIdPeminjaman);
            parentFrame.loadDataAktivitas();
            loadCombo();

            // Tutup form
            this.dispose();

        } catch (SQLException e) {
            System.out.println("Error Save Data: " + e.getMessage());
            JOptionPane.showMessageDialog(this, "Error saving data. Please try again.", "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void resetForm() {
        // Reset semua field input
        tfIdPengembalian.setText(""); // Reset ID Pengembalian
        comboPeminjaman.setSelectedIndex(0); // Reset ComboBox ID Peminjaman (tidak ada yang dipilih)
        tglMengembalikan.setDate(null); // Reset JDateChooser untuk tanggal mengembalikan
        denda.setText(""); // Reset JTextField denda
        jmlKembali.setValue(0); // Reset JSpinner jumlah buku
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jPanel2 = new javax.swing.JPanel();
        lblIdKembali = new javax.swing.JLabel();
        tfIdPengembalian = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnSaveInternal = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        telat = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        denda = new javax.swing.JTextField();
        comboPeminjaman = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        jmlKembali = new javax.swing.JSpinner();
        tglPinjam = new javax.swing.JTextField();
        tglKembali = new javax.swing.JTextField();
        tglMengembalikan = new com.toedter.calendar.JDateChooser();
        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        jPanel2.setBackground(new java.awt.Color(249, 247, 201));
        java.awt.GridBagLayout jPanel2Layout = new java.awt.GridBagLayout();
        jPanel2Layout.columnWidths = new int[] {0, 50, 0, 50, 0};
        jPanel2Layout.rowHeights = new int[] {0, 13, 0, 13, 0, 13, 0, 13, 0, 13, 0, 13, 0, 13, 0, 13, 0};
        jPanel2.setLayout(jPanel2Layout);

        lblIdKembali.setText("ID Pengembalian");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel2.add(lblIdKembali, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 0.1;
        jPanel2.add(tfIdPengembalian, gridBagConstraints);

        jLabel2.setText("ID Peminjaman");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel2.add(jLabel2, gridBagConstraints);

        jLabel4.setText("Tanggal Pinjam");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel2.add(jLabel4, gridBagConstraints);

        btnSaveInternal.setText("Tambah");
        btnSaveInternal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveInternalActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 16;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_END;
        jPanel2.add(btnSaveInternal, gridBagConstraints);

        jLabel1.setText("Tanggal Kembali");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel2.add(jLabel1, gridBagConstraints);

        jLabel3.setText("Tanggal Kembalikan");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel2.add(jLabel3, gridBagConstraints);

        jLabel5.setText("Telat");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 10;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel2.add(jLabel5, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 10;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel2.add(telat, gridBagConstraints);

        jLabel6.setText("Denda");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 12;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel2.add(jLabel6, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 12;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel2.add(denda, gridBagConstraints);

        comboPeminjaman.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboPeminjaman.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboPeminjamanActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel2.add(comboPeminjaman, gridBagConstraints);

        jLabel7.setText("Jumlah kembalikan");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 14;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel2.add(jLabel7, gridBagConstraints);

        jmlKembali.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 14;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel2.add(jmlKembali, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel2.add(tglPinjam, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel2.add(tglKembali, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel2.add(tglMengembalikan, gridBagConstraints);

        jButton2.setText("Reset");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 16;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        jPanel2.add(jButton2, gridBagConstraints);

        jButton1.setText("Batal");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 16;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_END;
        jPanel2.add(jButton1, gridBagConstraints);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 399, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSaveInternalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveInternalActionPerformed
        // TODO add your handling code here:
        saveData();
    }//GEN-LAST:event_btnSaveInternalActionPerformed

    private void comboPeminjamanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboPeminjamanActionPerformed
        // TODO add your handling code here:
        String selectedId = (String) comboPeminjaman.getSelectedItem();
        if (selectedId != null) {
            // Mengisi tanggal berdasarkan ID peminjaman
            fillDates(selectedId);
            // Cek jika tanggal sudah dipilih, jika belum, set tanggal saat ini
            if (tglMengembalikan.getDate() == null) {
                // Jika tanggal tidak dipilih sebelumnya, set tanggal default ke hari ini
                tglMengembalikan.setDate(new java.util.Date());
            }
            // Hitung keterlambatan dan denda berdasarkan tanggal yang sudah dipilih
            calculateTelatAndDenda();
        }
    }//GEN-LAST:event_comboPeminjamanActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        resetForm();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSaveInternal;
    private javax.swing.JComboBox<String> comboPeminjaman;
    private javax.swing.JTextField denda;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JSpinner jmlKembali;
    private javax.swing.JLabel lblIdKembali;
    private javax.swing.JTextField telat;
    private javax.swing.JTextField tfIdPengembalian;
    private javax.swing.JTextField tglKembali;
    private com.toedter.calendar.JDateChooser tglMengembalikan;
    private javax.swing.JTextField tglPinjam;
    // End of variables declaration//GEN-END:variables
}
