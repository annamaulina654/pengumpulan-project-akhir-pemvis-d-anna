
package perpus;

import Data.dashboard;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class NewJFrame extends javax.swing.JFrame {
    Connection conn;
    private DefaultTableModel modelTabel;
    private DefaultTableModel modelTabelAnggota;
    private DefaultTableModel modelTabelPeminjaman;
    private DefaultTableModel modelTabelPengembalian;
    private DefaultTableModel modelTabelAktivitas;

    public NewJFrame() {
        initComponents();
        
        conn = KoneksiDatabase.getConnection();
        modelTabel = new DefaultTableModel();
        modelTabelAnggota = new DefaultTableModel();
        modelTabelPeminjaman = new DefaultTableModel();
        modelTabelPengembalian = new DefaultTableModel();
        modelTabelAktivitas = new DefaultTableModel();
        
        tabelBuku.setModel(modelTabel);
        tabelAnggota.setModel(modelTabelAnggota);
        tabelPeminjaman.setModel(modelTabelPeminjaman);
        tabelPengembalian.setModel(modelTabelPengembalian);
        tabelAktivitas.setModel(modelTabelAktivitas);
        
        modelTabel.addColumn("ISBN");
        modelTabel.addColumn("Judul Buku");
        modelTabel.addColumn("Penulis");
        modelTabel.addColumn("Tahun Terbit");
        modelTabel.addColumn("Jenis Buku");
        modelTabel.addColumn("Penerbit");
        modelTabel.addColumn("Stok");
    
        modelTabelAnggota.addColumn("ID Anggota");
        modelTabelAnggota.addColumn("NIM");
        modelTabelAnggota.addColumn("Nama");
        modelTabelAnggota.addColumn("Prodi");
        modelTabelAnggota.addColumn("Fakultas");
    
        modelTabelPeminjaman.addColumn("ID Peminjaman");
        modelTabelPeminjaman.addColumn("Nama Peminjam");
        modelTabelPeminjaman.addColumn("ISBN");
        modelTabelPeminjaman.addColumn("Judul Buku");
        modelTabelPeminjaman.addColumn("Tanggal Pinjam");
        modelTabelPeminjaman.addColumn("Tanggal Kembali");
        modelTabelPeminjaman.addColumn("Jumlah");
        modelTabelPeminjaman.addColumn("Status");
        
        modelTabelPengembalian.addColumn("ID Pengembalian");
        modelTabelPengembalian.addColumn("ID Peminjaman");
        modelTabelPengembalian.addColumn("Nama Anggota");
        modelTabelPengembalian.addColumn("Buku yang dipinjam");
        modelTabelPengembalian.addColumn("Tanggal Pinjam");
        modelTabelPengembalian.addColumn("Tanggal Mengembalikan");
        modelTabelPengembalian.addColumn("Denda");
        
        modelTabelAktivitas.addColumn("Aktivitas");
        modelTabelAktivitas.addColumn("Waktu");
    
        loadData();
        loadDataAnggota();
        loadDataPeminjaman();
        loadDataPengembalian();
        loadDataAktivitas();
        tampilDataDashboard();
        
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        this.setSize(screenSize.width, screenSize.height);
    }
    
    void loadData() {
        modelTabel.setRowCount(0);

        try {
            String sql = "SELECT * FROM t_buku";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet hasil = ps.executeQuery();
            while (hasil.next()) {
                String isbn = hasil.getString("isbn");
                String judul = hasil.getString("judul_buku");
                String penulis = hasil.getString("penulis");
                String tahun = hasil.getString("tahun_terbit");
                String jenis = hasil.getString("jenis_buku");
                String penerbit = hasil.getString("penerbit");
                int stok = hasil.getInt("stok");

                // Tampilkan stok sebagai "Stok Habis" jika stok bernilai 0
                String stokDisplay = (stok == 0) ? "Stok Habis" : String.valueOf(stok);

                modelTabel.addRow(new Object[]{
                    isbn,
                    judul,
                    penulis,
                    tahun,
                    jenis,
                    penerbit,
                    stokDisplay
                });
            }
        } catch (SQLException e) {
            System.out.println("Error loading data: " + e.getMessage());
        }
    }

    void loadDataAnggota() {
        modelTabelAnggota.setRowCount(0);

        try {
            String sql = "SELECT * FROM t_anggota";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet hasil = ps.executeQuery();
            while (hasil.next()) {
                modelTabelAnggota.addRow(new Object[]{
                    hasil.getString("id_anggota"),
                    hasil.getString("nim"),
                    hasil.getString("nama"),
                    hasil.getString("prodi"),
                    hasil.getString("fakultas")
                });
            }
        } catch (SQLException e) {
           System.out.println("Error Save Data" + e.getMessage());
        } 
    }
        
    void loadDataPeminjaman() {
        modelTabelPeminjaman.setRowCount(0);

        try {
             String sql = "SELECT t_pinjam.id_peminjaman, "
                   + "t_anggota.nama, "
                   + "t_buku.isbn, "
                   + "t_buku.judul_buku, "
                   + "t_pinjam.tgl_pinjam, "
                   + "t_pinjam.tgl_kembali, "
                   + "t_pinjam.jumlah_buku, "
                   + "t_pinjam.status "
                   + "FROM t_pinjam "
                   + "JOIN t_anggota ON t_pinjam.id_anggota = t_anggota.id_anggota "
                   + "JOIN t_buku ON t_pinjam.isbn = t_buku.isbn "
                   + "ORDER BY t_pinjam.tgl_pinjam ASC, t_pinjam.id_peminjaman ASC";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet hasil = ps.executeQuery();
            while (hasil.next()) {
                modelTabelPeminjaman.addRow(new Object[]{
                    hasil.getString("id_peminjaman"),
                    hasil.getString("nama"),
                    hasil.getString("isbn"),
                    hasil.getString("judul_buku"),
                    hasil.getString("tgl_pinjam"),
                    hasil.getString("tgl_kembali"),
                    hasil.getString("jumlah_buku"),
                    hasil.getString("status")
                });
            }
        } catch (SQLException e) {
           System.out.println("Error Save Data" + e.getMessage());
        }
    }
            
    void loadDataPengembalian() {
        modelTabelPengembalian.setRowCount(0); // Reset model

        try {
            // SQL query untuk mendapatkan data dari beberapa tabel dengan JOIN
            String sql = "SELECT t_kembali.id_pengembalian, "
                       + "t_pinjam.id_peminjaman, "
                       + "t_anggota.nama, "
                       + "t_buku.judul_buku, "
                       + "t_pinjam.tgl_pinjam, "
                       + "t_kembali.tgl_mengembalikan, "
                       + "t_kembali.denda "
                       + "FROM t_pinjam "
                       + "JOIN t_anggota ON t_pinjam.id_anggota = t_anggota.id_anggota "
                       + "JOIN t_buku ON t_pinjam.isbn = t_buku.isbn "
                       + "JOIN t_kembali ON t_pinjam.id_peminjaman = t_kembali.id_peminjaman "
                       + "ORDER BY t_kembali.tgl_mengembalikan ASC, t_kembali.id_pengembalian ASC";

            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet hasil = ps.executeQuery();

            // Menambahkan data hasil query ke model tabel
            while (hasil.next()) {
                modelTabelPengembalian.addRow(new Object[]{
                    hasil.getString("id_pengembalian"),
                    hasil.getString("id_peminjaman"),
                    hasil.getString("nama"),
                    hasil.getString("judul_buku"),
                    hasil.getString("tgl_pinjam"),
                    hasil.getString("tgl_mengembalikan"), // Menggunakan tgl_kembali dari t_kembali
                    hasil.getString("denda")
                });
            }
        } catch (SQLException e) {
               System.out.println("Error Save Data" + e.getMessage());
        }     
    }
        
    void loadDataAktivitas() {
        modelTabelAktivitas.setRowCount(0);

        try {
            String sql = "SELECT * FROM t_aktivitas";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet hasil = ps.executeQuery();
            while (hasil.next()) {
                modelTabelAktivitas.addRow(new Object[]{
                    hasil.getString("aktivitas"),
                    hasil.getString("tglWaktu")
                });
            }
        } catch (SQLException e) {
           System.out.println("Error Save Data" + e.getMessage());
        }
    }
        
    public void tampilDataDashboard(){
        dashboard ds = new dashboard();
        
        ds.jumlahBuku();
        ds.jumlahAnggota();
        ds.jumlahAktifitas();
        ds.jumlahPinjam();
        ds.jumlahKembali();
        
        lblJmlBuku.setText(ds.getJmlBuku());
        lblJmlAnggota.setText(ds.getJmlAnggota());
        lblJmlPinjam.setText(ds.getJmlPinjam());
        lblJmlKembali.setText(ds.getJmlKembali());
        lblJmlAktivitas.setText(ds.getJmlAktivitas());
    }
            
    public void simpanAktivitas(String aktivitass) {
        String query = "INSERT INTO t_aktivitas (aktivitas, tglWaktu) VALUES (?, CURRENT_TIMESTAMP)";

        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, aktivitass);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void openLoginForm() {
        // Membuka form Register
        new Login().setVisible(true);
        this.dispose(); // Menutup form login
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        tabbedPane = new javax.swing.JTabbedPane();
        dashboard = new javax.swing.JPanel();
        dashboardInt = new javax.swing.JPanel();
        menuBuku1 = new javax.swing.JPanel();
        jLabel56 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        lblJmlBuku = new javax.swing.JLabel();
        menuPinjam1 = new javax.swing.JPanel();
        jLabel65 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        lblJmlPinjam = new javax.swing.JLabel();
        menuAnggota1 = new javax.swing.JPanel();
        jLabel62 = new javax.swing.JLabel();
        jLabel71 = new javax.swing.JLabel();
        lblJmlAnggota = new javax.swing.JLabel();
        menuAktivitas1 = new javax.swing.JPanel();
        jLabel72 = new javax.swing.JLabel();
        jLabel73 = new javax.swing.JLabel();
        lblJmlAktivitas = new javax.swing.JLabel();
        menuKembali1 = new javax.swing.JPanel();
        jLabel74 = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        lblJmlKembali = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        dataBuku = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        tfCari = new javax.swing.JTextField();
        cariBuku = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        btnTambahBuku = new javax.swing.JButton();
        btnEditBuku = new javax.swing.JButton();
        btnHapusBuku = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelBuku = new javax.swing.JTable();
        DesktopPane = new javax.swing.JDesktopPane();
        jPanel10 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        dataAnggota = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        tfCariAnggota = new javax.swing.JTextField();
        cariAnggota = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        btnTambahAnggota = new javax.swing.JButton();
        btnEditAnggota = new javax.swing.JButton();
        btnHapusAnggota = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabelAnggota = new javax.swing.JTable();
        jPanel12 = new javax.swing.JPanel();
        DesktopPane1 = new javax.swing.JDesktopPane();
        jPanel18 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jPanel24 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jPanel25 = new javax.swing.JPanel();
        peminjaman = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        tfCariPeminjaman = new javax.swing.JTextField();
        cariPeminjaman = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        btnTambahPeminjaman = new javax.swing.JButton();
        btnEditPinjam = new javax.swing.JButton();
        btnHapusPinjam = new javax.swing.JButton();
        jPanel15 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tabelPeminjaman = new javax.swing.JTable();
        jPanel16 = new javax.swing.JPanel();
        DesktopPane3 = new javax.swing.JDesktopPane();
        jPanel19 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jPanel26 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jPanel27 = new javax.swing.JPanel();
        pengembalian = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        tfCariKembali = new javax.swing.JTextField();
        cariKembali = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        btnTambahKembali = new javax.swing.JButton();
        btnHapusKembali = new javax.swing.JButton();
        jPanel21 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        tabelPengembalian = new javax.swing.JTable();
        jPanel22 = new javax.swing.JPanel();
        DesktopPane4 = new javax.swing.JDesktopPane();
        jPanel20 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jPanel28 = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        jPanel36 = new javax.swing.JPanel();
        aktivitas = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jPanel23 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        tabelAktivitas = new javax.swing.JTable();
        jPanel29 = new javax.swing.JPanel();
        jPanel37 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new java.awt.BorderLayout());

        jPanel3.setBackground(new java.awt.Color(213, 240, 193));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/bookIcon.png"))); // NOI18N
        jLabel2.setText("SiPerpusUniv");

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/Back.gif"))); // NOI18N
        jButton1.setText("Logout");
        jButton1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/Exit.gif"))); // NOI18N
        jButton2.setText("Exit");
        jButton2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 1250, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(18, 18, 18)
                .addComponent(jButton2)
                .addGap(48, 48, 48))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton1)
                        .addComponent(jButton2))
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(19, 19, 19))
        );

        jPanel1.add(jPanel3, java.awt.BorderLayout.PAGE_START);

        jPanel4.setBackground(new java.awt.Color(170, 217, 187));

        tabbedPane.setTabPlacement(javax.swing.JTabbedPane.LEFT);

        dashboard.setBackground(new java.awt.Color(128, 188, 189));

        dashboardInt.setBackground(new java.awt.Color(128, 188, 189));
        dashboardInt.setToolTipText("");
        dashboardInt.setPreferredSize(new java.awt.Dimension(680, 527));
        dashboardInt.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        menuBuku1.setBackground(new java.awt.Color(249, 247, 201));
        menuBuku1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuBuku1MouseClicked(evt);
            }
        });

        jLabel56.setFont(new java.awt.Font("Malgun Gothic Semilight", 0, 12)); // NOI18N
        jLabel56.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel56.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/book.png"))); // NOI18N
        jLabel56.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jLabel56.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel56MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel56MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel56MouseExited(evt);
            }
        });

        jLabel59.setFont(new java.awt.Font("Malgun Gothic Semilight", 0, 12)); // NOI18N
        jLabel59.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel59.setText("Jumlah Buku");

        lblJmlBuku.setFont(new java.awt.Font("Malgun Gothic Semilight", 1, 18)); // NOI18N
        lblJmlBuku.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblJmlBuku.setText("0");

        javax.swing.GroupLayout menuBuku1Layout = new javax.swing.GroupLayout(menuBuku1);
        menuBuku1.setLayout(menuBuku1Layout);
        menuBuku1Layout.setHorizontalGroup(
            menuBuku1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel56, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel59, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(lblJmlBuku, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        menuBuku1Layout.setVerticalGroup(
            menuBuku1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuBuku1Layout.createSequentialGroup()
                .addComponent(jLabel56, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel59)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblJmlBuku, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        dashboardInt.add(menuBuku1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 180, 140));

        menuPinjam1.setBackground(new java.awt.Color(249, 247, 201));
        menuPinjam1.setPreferredSize(new java.awt.Dimension(190, 140));
        menuPinjam1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuPinjam1MouseClicked(evt);
            }
        });

        jLabel65.setFont(new java.awt.Font("Malgun Gothic Semilight", 0, 12)); // NOI18N
        jLabel65.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel65.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/peminjaman.png"))); // NOI18N
        jLabel65.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jLabel65.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel65MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel65MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel65MouseExited(evt);
            }
        });

        jLabel68.setFont(new java.awt.Font("Malgun Gothic Semilight", 0, 12)); // NOI18N
        jLabel68.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel68.setText("Peminjaman Hari Ini");

        lblJmlPinjam.setFont(new java.awt.Font("Malgun Gothic Semilight", 1, 18)); // NOI18N
        lblJmlPinjam.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblJmlPinjam.setText("0");

        javax.swing.GroupLayout menuPinjam1Layout = new javax.swing.GroupLayout(menuPinjam1);
        menuPinjam1.setLayout(menuPinjam1Layout);
        menuPinjam1Layout.setHorizontalGroup(
            menuPinjam1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuPinjam1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(menuPinjam1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel65, javax.swing.GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE)
                    .addComponent(lblJmlPinjam, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(menuPinjam1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(menuPinjam1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel68, javax.swing.GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        menuPinjam1Layout.setVerticalGroup(
            menuPinjam1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuPinjam1Layout.createSequentialGroup()
                .addComponent(jLabel65, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(lblJmlPinjam, javax.swing.GroupLayout.DEFAULT_SIZE, 47, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(menuPinjam1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(menuPinjam1Layout.createSequentialGroup()
                    .addGap(61, 61, 61)
                    .addComponent(jLabel68)
                    .addContainerGap(62, Short.MAX_VALUE)))
        );

        dashboardInt.add(menuPinjam1, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 50, -1, -1));

        menuAnggota1.setBackground(new java.awt.Color(249, 247, 201));
        menuAnggota1.setPreferredSize(new java.awt.Dimension(190, 140));
        menuAnggota1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuAnggota1MouseClicked(evt);
            }
        });

        jLabel62.setFont(new java.awt.Font("Malgun Gothic Semilight", 0, 12)); // NOI18N
        jLabel62.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel62.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/member.png"))); // NOI18N
        jLabel62.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jLabel62.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel62MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel62MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel62MouseExited(evt);
            }
        });

        jLabel71.setFont(new java.awt.Font("Malgun Gothic Semilight", 0, 12)); // NOI18N
        jLabel71.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel71.setText("Jumlah Anggota");

        lblJmlAnggota.setFont(new java.awt.Font("Malgun Gothic Semilight", 1, 18)); // NOI18N
        lblJmlAnggota.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblJmlAnggota.setText("0");

        javax.swing.GroupLayout menuAnggota1Layout = new javax.swing.GroupLayout(menuAnggota1);
        menuAnggota1.setLayout(menuAnggota1Layout);
        menuAnggota1Layout.setHorizontalGroup(
            menuAnggota1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel62, javax.swing.GroupLayout.DEFAULT_SIZE, 190, Short.MAX_VALUE)
            .addGroup(menuAnggota1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblJmlAnggota, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(menuAnggota1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(menuAnggota1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel71, javax.swing.GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        menuAnggota1Layout.setVerticalGroup(
            menuAnggota1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuAnggota1Layout.createSequentialGroup()
                .addComponent(jLabel62, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(lblJmlAnggota, javax.swing.GroupLayout.DEFAULT_SIZE, 47, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(menuAnggota1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(menuAnggota1Layout.createSequentialGroup()
                    .addGap(61, 61, 61)
                    .addComponent(jLabel71)
                    .addContainerGap(62, Short.MAX_VALUE)))
        );

        dashboardInt.add(menuAnggota1, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 50, -1, -1));

        menuAktivitas1.setBackground(new java.awt.Color(249, 247, 201));
        menuAktivitas1.setPreferredSize(new java.awt.Dimension(190, 140));
        menuAktivitas1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuAktivitas1MouseClicked(evt);
            }
        });

        jLabel72.setFont(new java.awt.Font("Malgun Gothic Semilight", 0, 12)); // NOI18N
        jLabel72.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel72.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/activity.png"))); // NOI18N
        jLabel72.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jLabel72.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel72MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel72MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel72MouseExited(evt);
            }
        });

        jLabel73.setFont(new java.awt.Font("Malgun Gothic Semilight", 0, 12)); // NOI18N
        jLabel73.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel73.setText("Aktivitas Hari Ini");

        lblJmlAktivitas.setFont(new java.awt.Font("Malgun Gothic Semilight", 1, 18)); // NOI18N
        lblJmlAktivitas.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblJmlAktivitas.setText("0");

        javax.swing.GroupLayout menuAktivitas1Layout = new javax.swing.GroupLayout(menuAktivitas1);
        menuAktivitas1.setLayout(menuAktivitas1Layout);
        menuAktivitas1Layout.setHorizontalGroup(
            menuAktivitas1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuAktivitas1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(menuAktivitas1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel72, javax.swing.GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE)
                    .addComponent(lblJmlAktivitas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(menuAktivitas1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(menuAktivitas1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel73, javax.swing.GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        menuAktivitas1Layout.setVerticalGroup(
            menuAktivitas1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuAktivitas1Layout.createSequentialGroup()
                .addComponent(jLabel72, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(lblJmlAktivitas, javax.swing.GroupLayout.DEFAULT_SIZE, 47, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(menuAktivitas1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(menuAktivitas1Layout.createSequentialGroup()
                    .addGap(61, 61, 61)
                    .addComponent(jLabel73)
                    .addContainerGap(62, Short.MAX_VALUE)))
        );

        dashboardInt.add(menuAktivitas1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 50, -1, -1));

        menuKembali1.setBackground(new java.awt.Color(249, 247, 201));
        menuKembali1.setPreferredSize(new java.awt.Dimension(190, 140));
        menuKembali1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuKembali1MouseClicked(evt);
            }
        });

        jLabel74.setFont(new java.awt.Font("Malgun Gothic Semilight", 0, 12)); // NOI18N
        jLabel74.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel74.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/pengembalian.png"))); // NOI18N
        jLabel74.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jLabel74.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel74MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel74MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel74MouseExited(evt);
            }
        });

        jLabel75.setFont(new java.awt.Font("Malgun Gothic Semilight", 0, 12)); // NOI18N
        jLabel75.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel75.setText("Pengembalian Hari Ini");

        lblJmlKembali.setFont(new java.awt.Font("Malgun Gothic Semilight", 1, 18)); // NOI18N
        lblJmlKembali.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblJmlKembali.setText("0");

        javax.swing.GroupLayout menuKembali1Layout = new javax.swing.GroupLayout(menuKembali1);
        menuKembali1.setLayout(menuKembali1Layout);
        menuKembali1Layout.setHorizontalGroup(
            menuKembali1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuKembali1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(menuKembali1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel74, javax.swing.GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE)
                    .addComponent(lblJmlKembali, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(menuKembali1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(menuKembali1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel75, javax.swing.GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        menuKembali1Layout.setVerticalGroup(
            menuKembali1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuKembali1Layout.createSequentialGroup()
                .addComponent(jLabel74, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(lblJmlKembali, javax.swing.GroupLayout.DEFAULT_SIZE, 47, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(menuKembali1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(menuKembali1Layout.createSequentialGroup()
                    .addGap(61, 61, 61)
                    .addComponent(jLabel75)
                    .addContainerGap(62, Short.MAX_VALUE)))
        );

        dashboardInt.add(menuKembali1, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 50, -1, -1));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/dashboard.png"))); // NOI18N
        dashboardInt.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 230, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel5.setText("Welcome!");
        dashboardInt.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 260, -1, -1));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel13.setText("This is the dashboard menu");
        dashboardInt.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 320, -1, -1));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/dashboard2.png"))); // NOI18N
        dashboardInt.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 360, -1, -1));

        javax.swing.GroupLayout dashboardLayout = new javax.swing.GroupLayout(dashboard);
        dashboard.setLayout(dashboardLayout);
        dashboardLayout.setHorizontalGroup(
            dashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(dashboardInt, javax.swing.GroupLayout.DEFAULT_SIZE, 1536, Short.MAX_VALUE)
        );
        dashboardLayout.setVerticalGroup(
            dashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dashboardLayout.createSequentialGroup()
                .addComponent(dashboardInt, javax.swing.GroupLayout.PREFERRED_SIZE, 753, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        tabbedPane.addTab("Dashboard", dashboard);

        dataBuku.setBackground(new java.awt.Color(128, 188, 189));
        dataBuku.setLayout(new java.awt.BorderLayout());

        jPanel2.setBackground(new java.awt.Color(128, 188, 189));
        java.awt.GridBagLayout jPanel2Layout = new java.awt.GridBagLayout();
        jPanel2Layout.columnWidths = new int[] {0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0};
        jPanel2Layout.rowHeights = new int[] {0, 13, 0, 13, 0, 13, 0};
        jPanel2.setLayout(jPanel2Layout);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 6;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 7;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel2.add(tfCari, gridBagConstraints);

        cariBuku.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/Find.gif"))); // NOI18N
        cariBuku.setText("Cari");
        cariBuku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cariBukuActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 14;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_END;
        jPanel2.add(cariBuku, gridBagConstraints);

        jLabel3.setText("Cari Buku");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        jPanel2.add(jLabel3, gridBagConstraints);

        btnTambahBuku.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/Add.gif"))); // NOI18N
        btnTambahBuku.setText("Add");
        btnTambahBuku.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnTambahBuku.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnTambahBuku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTambahBukuActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 10;
        gridBagConstraints.gridy = 4;
        jPanel2.add(btnTambahBuku, gridBagConstraints);

        btnEditBuku.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/Modify.gif"))); // NOI18N
        btnEditBuku.setText("Update");
        btnEditBuku.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnEditBuku.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnEditBuku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditBukuActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 12;
        gridBagConstraints.gridy = 4;
        jPanel2.add(btnEditBuku, gridBagConstraints);

        btnHapusBuku.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/Delete.gif"))); // NOI18N
        btnHapusBuku.setText("Delete");
        btnHapusBuku.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnHapusBuku.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnHapusBuku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHapusBukuActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 14;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_END;
        jPanel2.add(btnHapusBuku, gridBagConstraints);

        dataBuku.add(jPanel2, java.awt.BorderLayout.PAGE_START);

        jPanel5.setBackground(new java.awt.Color(128, 188, 189));

        tabelBuku.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tabelBuku);

        DesktopPane.setBackground(new java.awt.Color(128, 188, 189));

        jPanel10.setBackground(new java.awt.Color(128, 188, 189));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/dataBook.png"))); // NOI18N

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addContainerGap(17, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(137, 137, 137)
                .addComponent(jLabel8)
                .addContainerGap(295, Short.MAX_VALUE))
        );

        DesktopPane.setLayer(jPanel10, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout DesktopPaneLayout = new javax.swing.GroupLayout(DesktopPane);
        DesktopPane.setLayout(DesktopPaneLayout);
        DesktopPaneLayout.setHorizontalGroup(
            DesktopPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        DesktopPaneLayout.setVerticalGroup(
            DesktopPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel9.setBackground(new java.awt.Color(249, 247, 201));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/buku1.png"))); // NOI18N
        jLabel15.setText("Data Buku");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addComponent(jLabel15)
                .addGap(0, 6, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel15)
                .addContainerGap())
        );

        jPanel13.setBackground(new java.awt.Color(249, 247, 201));

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 177, Short.MAX_VALUE)
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 14, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 804, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(DesktopPane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(DesktopPane)
                .addGap(111, 111, 111))
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(7, 7, 7)
                .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 361, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        dataBuku.add(jPanel5, java.awt.BorderLayout.CENTER);

        tabbedPane.addTab("Data Buku", dataBuku);

        dataAnggota.setBackground(new java.awt.Color(250, 250, 250));
        dataAnggota.setLayout(new java.awt.BorderLayout());

        jPanel7.setBackground(new java.awt.Color(128, 188, 189));
        java.awt.GridBagLayout jPanel7Layout = new java.awt.GridBagLayout();
        jPanel7Layout.columnWidths = new int[] {0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0};
        jPanel7Layout.rowHeights = new int[] {0, 13, 0, 13, 0, 13, 0};
        jPanel7.setLayout(jPanel7Layout);

        tfCariAnggota.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfCariAnggotaActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 14;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 7;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel7.add(tfCariAnggota, gridBagConstraints);

        cariAnggota.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/Find.gif"))); // NOI18N
        cariAnggota.setText("Cari");
        cariAnggota.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cariAnggotaActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 22;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_END;
        jPanel7.add(cariAnggota, gridBagConstraints);

        jLabel4.setText("Cari Anggota");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 8;
        gridBagConstraints.gridy = 2;
        jPanel7.add(jLabel4, gridBagConstraints);

        btnTambahAnggota.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/Add.gif"))); // NOI18N
        btnTambahAnggota.setText("Add");
        btnTambahAnggota.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnTambahAnggota.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnTambahAnggota.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTambahAnggotaActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 18;
        gridBagConstraints.gridy = 4;
        jPanel7.add(btnTambahAnggota, gridBagConstraints);

        btnEditAnggota.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/Modify.gif"))); // NOI18N
        btnEditAnggota.setText("Update");
        btnEditAnggota.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnEditAnggota.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnEditAnggota.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditAnggotaActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 20;
        gridBagConstraints.gridy = 4;
        jPanel7.add(btnEditAnggota, gridBagConstraints);

        btnHapusAnggota.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/Delete.gif"))); // NOI18N
        btnHapusAnggota.setText("Delete");
        btnHapusAnggota.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnHapusAnggota.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnHapusAnggota.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHapusAnggotaActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 22;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_END;
        jPanel7.add(btnHapusAnggota, gridBagConstraints);

        dataAnggota.add(jPanel7, java.awt.BorderLayout.PAGE_START);

        jPanel8.setBackground(new java.awt.Color(128, 188, 189));

        tabelAnggota.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tabelAnggota);

        DesktopPane1.setBackground(new java.awt.Color(128, 188, 189));

        jPanel18.setBackground(new java.awt.Color(128, 188, 189));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/dataAnggota.png"))); // NOI18N

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel18Layout.createSequentialGroup()
                .addContainerGap(30, Short.MAX_VALUE)
                .addComponent(jLabel9)
                .addGap(7, 7, 7))
        );

        DesktopPane1.setLayer(jPanel18, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout DesktopPane1Layout = new javax.swing.GroupLayout(DesktopPane1);
        DesktopPane1.setLayout(DesktopPane1Layout);
        DesktopPane1Layout.setHorizontalGroup(
            DesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        DesktopPane1Layout.setVerticalGroup(
            DesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(DesktopPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(DesktopPane1)
        );

        jPanel14.setBackground(new java.awt.Color(249, 247, 201));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/buku1.png"))); // NOI18N
        jLabel16.setText("Data Buku");

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addComponent(jLabel16)
                .addGap(0, 6, Short.MAX_VALUE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel16)
                .addContainerGap())
        );

        jPanel24.setBackground(new java.awt.Color(249, 247, 201));

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/anggota.png"))); // NOI18N
        jLabel17.setText("Data Anggota");

        javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel24Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel17)
                .addContainerGap())
        );

        jPanel25.setBackground(new java.awt.Color(249, 247, 201));

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 208, Short.MAX_VALUE)
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 14, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 830, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel8Layout.createSequentialGroup()
                    .addGap(690, 690, 690)
                    .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(706, Short.MAX_VALUE)))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jPanel24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(13, 13, 13)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(325, Short.MAX_VALUE))
            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel8Layout.createSequentialGroup()
                    .addGap(392, 392, 392)
                    .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(393, Short.MAX_VALUE)))
        );

        dataAnggota.add(jPanel8, java.awt.BorderLayout.CENTER);

        tabbedPane.addTab("Data Anggota", dataAnggota);

        peminjaman.setLayout(new java.awt.BorderLayout());

        jPanel6.setBackground(new java.awt.Color(128, 188, 189));
        java.awt.GridBagLayout jPanel6Layout = new java.awt.GridBagLayout();
        jPanel6Layout.columnWidths = new int[] {0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0};
        jPanel6Layout.rowHeights = new int[] {0, 13, 0, 13, 0, 13, 0};
        jPanel6.setLayout(jPanel6Layout);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 14;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 7;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel6.add(tfCariPeminjaman, gridBagConstraints);

        cariPeminjaman.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/Find.gif"))); // NOI18N
        cariPeminjaman.setText("Cari");
        cariPeminjaman.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cariPeminjamanActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 22;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_END;
        jPanel6.add(cariPeminjaman, gridBagConstraints);

        jLabel6.setText("Cari Peminjaman");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 8;
        gridBagConstraints.gridy = 2;
        jPanel6.add(jLabel6, gridBagConstraints);

        btnTambahPeminjaman.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/Add.gif"))); // NOI18N
        btnTambahPeminjaman.setText("Add");
        btnTambahPeminjaman.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnTambahPeminjaman.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnTambahPeminjaman.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTambahPeminjamanActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 18;
        gridBagConstraints.gridy = 4;
        jPanel6.add(btnTambahPeminjaman, gridBagConstraints);

        btnEditPinjam.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/Modify.gif"))); // NOI18N
        btnEditPinjam.setText("Update");
        btnEditPinjam.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnEditPinjam.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnEditPinjam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditPinjamActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 20;
        gridBagConstraints.gridy = 4;
        jPanel6.add(btnEditPinjam, gridBagConstraints);

        btnHapusPinjam.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/Delete.gif"))); // NOI18N
        btnHapusPinjam.setText("Delete");
        btnHapusPinjam.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnHapusPinjam.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnHapusPinjam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHapusPinjamActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 22;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_END;
        jPanel6.add(btnHapusPinjam, gridBagConstraints);

        peminjaman.add(jPanel6, java.awt.BorderLayout.PAGE_START);

        jPanel15.setBackground(new java.awt.Color(128, 188, 189));

        tabelPeminjaman.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6", "Title 7"
            }
        ));
        jScrollPane4.setViewportView(tabelPeminjaman);

        DesktopPane3.setBackground(new java.awt.Color(128, 188, 189));

        jPanel19.setBackground(new java.awt.Color(128, 188, 189));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/dataPeminjaman.png"))); // NOI18N

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addContainerGap(317, Short.MAX_VALUE))
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 410, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        DesktopPane3.setLayer(jPanel19, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout DesktopPane3Layout = new javax.swing.GroupLayout(DesktopPane3);
        DesktopPane3.setLayout(DesktopPane3Layout);
        DesktopPane3Layout.setHorizontalGroup(
            DesktopPane3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        DesktopPane3Layout.setVerticalGroup(
            DesktopPane3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(DesktopPane3)
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(DesktopPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        jPanel26.setBackground(new java.awt.Color(249, 247, 201));

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pinjam.png"))); // NOI18N
        jLabel18.setText("Peminjaman");

        javax.swing.GroupLayout jPanel26Layout = new javax.swing.GroupLayout(jPanel26);
        jPanel26.setLayout(jPanel26Layout);
        jPanel26Layout.setHorizontalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel26Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel18, javax.swing.GroupLayout.DEFAULT_SIZE, 154, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel26Layout.setVerticalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel26Layout.createSequentialGroup()
                .addContainerGap(10, Short.MAX_VALUE)
                .addComponent(jLabel18)
                .addContainerGap())
        );

        jPanel27.setBackground(new java.awt.Color(249, 247, 201));

        javax.swing.GroupLayout jPanel27Layout = new javax.swing.GroupLayout(jPanel27);
        jPanel27.setLayout(jPanel27Layout);
        jPanel27Layout.setHorizontalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 200, Short.MAX_VALUE)
        );
        jPanel27Layout.setVerticalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 14, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 745, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel26, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(jPanel26, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(320, Short.MAX_VALUE))
        );

        peminjaman.add(jPanel15, java.awt.BorderLayout.CENTER);

        tabbedPane.addTab("Peminjaman", peminjaman);

        pengembalian.setLayout(new java.awt.BorderLayout());

        jPanel11.setBackground(new java.awt.Color(128, 188, 189));
        java.awt.GridBagLayout jPanel11Layout = new java.awt.GridBagLayout();
        jPanel11Layout.columnWidths = new int[] {0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0, 23, 0};
        jPanel11Layout.rowHeights = new int[] {0, 13, 0, 13, 0, 13, 0};
        jPanel11.setLayout(jPanel11Layout);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 14;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 7;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel11.add(tfCariKembali, gridBagConstraints);

        cariKembali.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/Find.gif"))); // NOI18N
        cariKembali.setText("Cari");
        cariKembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cariKembaliActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 22;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_END;
        jPanel11.add(cariKembali, gridBagConstraints);

        jLabel7.setText("Cari Pengembalian");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 8;
        gridBagConstraints.gridy = 2;
        jPanel11.add(jLabel7, gridBagConstraints);

        btnTambahKembali.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/Add.gif"))); // NOI18N
        btnTambahKembali.setText("Add");
        btnTambahKembali.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnTambahKembali.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnTambahKembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTambahKembaliActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 18;
        gridBagConstraints.gridy = 4;
        jPanel11.add(btnTambahKembali, gridBagConstraints);

        btnHapusKembali.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/Delete.gif"))); // NOI18N
        btnHapusKembali.setText("Delete");
        btnHapusKembali.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnHapusKembali.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnHapusKembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHapusKembaliActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 22;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_END;
        jPanel11.add(btnHapusKembali, gridBagConstraints);

        pengembalian.add(jPanel11, java.awt.BorderLayout.PAGE_START);

        jPanel21.setBackground(new java.awt.Color(128, 188, 189));

        tabelPengembalian.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane5.setViewportView(tabelPengembalian);

        DesktopPane4.setBackground(new java.awt.Color(128, 188, 189));

        jPanel20.setBackground(new java.awt.Color(128, 188, 189));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/dataPengembalian.png"))); // NOI18N

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addGap(93, 93, 93)
                .addComponent(jLabel11)
                .addContainerGap(65, Short.MAX_VALUE))
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addGap(112, 112, 112)
                .addComponent(jLabel11)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        DesktopPane4.setLayer(jPanel20, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout DesktopPane4Layout = new javax.swing.GroupLayout(DesktopPane4);
        DesktopPane4.setLayout(DesktopPane4Layout);
        DesktopPane4Layout.setHorizontalGroup(
            DesktopPane4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DesktopPane4Layout.createSequentialGroup()
                .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 286, Short.MAX_VALUE))
        );
        DesktopPane4Layout.setVerticalGroup(
            DesktopPane4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(DesktopPane4)
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addComponent(DesktopPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel28.setBackground(new java.awt.Color(249, 247, 201));

        jLabel25.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/kembali.png"))); // NOI18N
        jLabel25.setText("Pengembalian");

        javax.swing.GroupLayout jPanel28Layout = new javax.swing.GroupLayout(jPanel28);
        jPanel28.setLayout(jPanel28Layout);
        jPanel28Layout.setHorizontalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel28Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel25)
                .addContainerGap(9, Short.MAX_VALUE))
        );
        jPanel28Layout.setVerticalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel28Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel25)
                .addContainerGap())
        );

        jPanel36.setBackground(new java.awt.Color(249, 247, 201));

        javax.swing.GroupLayout jPanel36Layout = new javax.swing.GroupLayout(jPanel36);
        jPanel36.setLayout(jPanel36Layout);
        jPanel36Layout.setHorizontalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 208, Short.MAX_VALUE)
        );
        jPanel36Layout.setVerticalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 14, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 748, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel28, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel36, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel21Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jPanel28, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel36, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, 427, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(311, Short.MAX_VALUE))
        );

        pengembalian.add(jPanel21, java.awt.BorderLayout.CENTER);

        tabbedPane.addTab("Pengembalian", pengembalian);

        aktivitas.setLayout(new java.awt.BorderLayout());

        jPanel17.setBackground(new java.awt.Color(170, 217, 187));
        jPanel17.setLayout(new java.awt.GridBagLayout());
        aktivitas.add(jPanel17, java.awt.BorderLayout.PAGE_START);

        jPanel23.setBackground(new java.awt.Color(128, 188, 189));

        tabelAktivitas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane6.setViewportView(tabelAktivitas);

        jPanel29.setBackground(new java.awt.Color(249, 247, 201));

        javax.swing.GroupLayout jPanel29Layout = new javax.swing.GroupLayout(jPanel29);
        jPanel29.setLayout(jPanel29Layout);
        jPanel29Layout.setHorizontalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 177, Short.MAX_VALUE)
        );
        jPanel29Layout.setVerticalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 14, Short.MAX_VALUE)
        );

        jPanel37.setBackground(new java.awt.Color(249, 247, 201));

        jLabel26.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/aktivitas.png"))); // NOI18N
        jLabel26.setText("Aktivitas");

        javax.swing.GroupLayout jPanel37Layout = new javax.swing.GroupLayout(jPanel37);
        jPanel37.setLayout(jPanel37Layout);
        jPanel37Layout.setHorizontalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel37Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel26)
                .addContainerGap(14, Short.MAX_VALUE))
        );
        jPanel37Layout.setVerticalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel37Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel26)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 1524, Short.MAX_VALUE)
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel37, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel37, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(426, Short.MAX_VALUE))
        );

        aktivitas.add(jPanel23, java.awt.BorderLayout.CENTER);

        tabbedPane.addTab("Aktivitas", aktivitas);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabbedPane)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabbedPane)
        );

        jPanel1.add(jPanel4, java.awt.BorderLayout.CENTER);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnTambahKembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTambahKembaliActionPerformed
        // TODO add your handling code here:
        FormPengembalian fk = new FormPengembalian(this);
        fk.setSize(DesktopPane4.getSize());
        DesktopPane4.add(fk);
        fk.setVisible(true);
    }//GEN-LAST:event_btnTambahKembaliActionPerformed

    private void cariKembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cariKembaliActionPerformed
        // TODO add your handling code here:
        String keyword = tfCariKembali.getText().trim();

        // Jika TextField kosong, tampilkan semua data
        if (keyword.isEmpty()) {
            loadDataPengembalian(); // Jika tfCari kosong, tampilkan semua data
            return;
        }

        // Kosongkan tabel sebelum menambahkan data baru
        modelTabelPengembalian.setRowCount(0);

        try {
            // Query untuk mencari berdasarkan nama anggota
            String sql = "SELECT t_kembali.id_pengembalian, "
                       + "t_pinjam.id_peminjaman, "
                       + "t_anggota.nama, "
                       + "t_buku.judul_buku, "
                       + "t_pinjam.tgl_pinjam, "
                       + "t_kembali.tgl_mengembalikan, "
                       + "t_kembali.denda "
                       + "FROM t_pinjam "
                       + "JOIN t_anggota ON t_pinjam.id_anggota = t_anggota.id_anggota "
                       + "JOIN t_buku ON t_pinjam.isbn = t_buku.isbn "
                       + "JOIN t_kembali ON t_pinjam.id_peminjaman = t_kembali.id_peminjaman "
                       + "WHERE t_anggota.nama LIKE ? "
                       + "ORDER BY t_kembali.tgl_mengembalikan ASC, t_kembali.id_pengembalian ASC";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, "%" + keyword + "%"); // Mencari berdasarkan nama anggota

            ResultSet hasil = ps.executeQuery();

            // Menambahkan hasil pencarian ke dalam tabel
            while (hasil.next()) {
                modelTabelPengembalian.addRow(new Object[]{
                    hasil.getString("id_pengembalian"),
                    hasil.getString("id_peminjaman"),
                    hasil.getString("nama"),
                    hasil.getString("judul_buku"),
                    hasil.getString("tgl_pinjam"),
                    hasil.getString("tgl_mengembalikan"), // Tanggal pengembalian
                    hasil.getString("denda")
                });
            }
        } catch (SQLException e) {
            System.out.println("Error while searching: " + e.getMessage());
            JOptionPane.showMessageDialog(this, "Error while searching data",
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_cariKembaliActionPerformed

    private void btnTambahPeminjamanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTambahPeminjamanActionPerformed
        // TODO add your handling code here:
        FormPeminjaman fp = new FormPeminjaman(this);
        fp.setSize(DesktopPane3.getSize());
        DesktopPane3.add(fp);
        fp.setVisible(true);
    }//GEN-LAST:event_btnTambahPeminjamanActionPerformed

    private void cariPeminjamanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cariPeminjamanActionPerformed
        // TODO add your handling code here:
        String keyword = tfCariPeminjaman.getText().trim();
        // Jika TextField kosong, tampilkan semua data
        if (keyword.isEmpty()) {
            loadDataPeminjaman(); // Jika tfCari kosong, tampilkan semua data
            return;
        }
        // Kosongkan tabel sebelum menambahkan data baru
        modelTabelPeminjaman.setRowCount(0);

        try {
            // Query untuk mencari berdasarkan nama anggota
            String sql = "SELECT t_pinjam.id_peminjaman, "
                       + "t_anggota.nama, "
                       + "t_buku.isbn, "
                       + "t_buku.judul_buku, "
                       + "t_pinjam.tgl_pinjam, "
                       + "t_pinjam.tgl_kembali, "
                       + "t_pinjam.jumlah_buku, "
                       + "t_pinjam.status "
                       + "FROM t_pinjam "
                       + "JOIN t_anggota ON t_pinjam.id_anggota = t_anggota.id_anggota "
                       + "JOIN t_buku ON t_pinjam.isbn = t_buku.isbn "
                       + "WHERE t_anggota.nama LIKE ? "
                       + "ORDER BY t_pinjam.tgl_pinjam ASC, t_pinjam.id_peminjaman ASC";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, "%" + keyword + "%"); // Mencari berdasarkan nama anggota

            ResultSet hasil = ps.executeQuery();

            // Menambahkan hasil pencarian ke dalam tabel
            while (hasil.next()) {
                modelTabelPeminjaman.addRow(new Object[]{
                    hasil.getString("id_peminjaman"),
                    hasil.getString("nama"),
                    hasil.getString("isbn"),
                    hasil.getString("judul_buku"),
                    hasil.getString("tgl_pinjam"),
                    hasil.getString("tgl_kembali"),
                    hasil.getString("jumlah_buku"),
                    hasil.getString("status")
                });
            }
        } catch (SQLException e) {
            System.out.println("Error while searching: " + e.getMessage());
            JOptionPane.showMessageDialog(this, "Error while searching data",
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_cariPeminjamanActionPerformed

    private void btnHapusAnggotaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHapusAnggotaActionPerformed
        // TODO add your handling code here:
        int selectedRow = tabelAnggota.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a row to delete.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String id = modelTabelAnggota.getValueAt(selectedRow, 0).toString();

        int response = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to delete this data?",
            "Confirm Deletion",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);

        if (response == JOptionPane.YES_OPTION) {
            try {
                String sql = "DELETE FROM t_anggota WHERE id_anggota = ?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, id);
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Data deleted successfully");
                loadDataAnggota();
                tampilDataDashboard();
                simpanAktivitas("Menghapus anggota dengan id : " + id);
                loadDataAktivitas();

            } catch (SQLException e) {
                System.out.println("Error Save Data" + e.getMessage());
            }
        }
    }//GEN-LAST:event_btnHapusAnggotaActionPerformed

    private void btnEditAnggotaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditAnggotaActionPerformed
        // TODO add your handling code here:
        int selectedRow = tabelAnggota.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a row to edit.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Ambil data dari baris yang dipilih
        String id = modelTabelAnggota.getValueAt(selectedRow, 0).toString();
        String nim = modelTabelAnggota.getValueAt(selectedRow, 1).toString();
        String nama = modelTabelAnggota.getValueAt(selectedRow, 2).toString();
        String prodi = modelTabelAnggota.getValueAt(selectedRow, 3).toString();
        String fakultas = modelTabelAnggota.getValueAt(selectedRow, 4).toString();

        // Buka FormBuku dalam mode edit
        FormAnggota fa = new FormAnggota(this);
        fa.setDataForEdit(id, nim, nama, prodi, fakultas);
        fa.setSize(DesktopPane1.getSize());// Mengisi data di form
        DesktopPane1.add(fa);
        fa.setVisible(true);
    }//GEN-LAST:event_btnEditAnggotaActionPerformed

    private void btnTambahAnggotaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTambahAnggotaActionPerformed
        // TODO add your handling code here:
        FormAnggota fa = new FormAnggota(this);
        fa.setSize(DesktopPane1.getSize());
        DesktopPane1.add(fa);
        fa.setVisible(true);
    }//GEN-LAST:event_btnTambahAnggotaActionPerformed

    private void cariAnggotaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cariAnggotaActionPerformed
        // TODO add your handling code here:
        String keyword = tfCariAnggota.getText().trim();
        if (keyword.isEmpty()) {
            loadDataAnggota(); // Jika tfCari kosong, tampilkan semua data
            return;
        }

        // Kosongkan tabel sebelum menambahkan data baru
        modelTabelAnggota.setRowCount(0);

        try {
            String sql = "SELECT * FROM t_anggota WHERE nama LIKE ? or nim LIKE ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");

            ResultSet hasil = ps.executeQuery();
            while (hasil.next()) {
                modelTabelAnggota.addRow(new Object[]{
                    hasil.getString("id_anggota"),
                    hasil.getString("nim"),
                    hasil.getString("nama"),
                    hasil.getString("prodi"),
                    hasil.getString("fakultas")
                });
            }
        } catch (SQLException e) {
            System.out.println("Error while searching: " + e.getMessage());
            JOptionPane.showMessageDialog(this, "Error while searching data",
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_cariAnggotaActionPerformed

    private void tfCariAnggotaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfCariAnggotaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfCariAnggotaActionPerformed

    private void btnHapusBukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHapusBukuActionPerformed
        // TODO add your handling code here:
        int selectedRow = tabelBuku.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a row to delete.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String isbn = modelTabel.getValueAt(selectedRow, 0).toString();

        int response = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to delete this data?",
            "Confirm Deletion",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);

        if (response == JOptionPane.YES_OPTION) {
            try {
                String sql = "DELETE FROM t_buku WHERE isbn = ?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, isbn);
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Data deleted successfully");
                loadData();
                tampilDataDashboard();
                simpanAktivitas("Menghapus buku dengan isbn : " + isbn);
                loadDataAktivitas();

            } catch (SQLException e) {
                System.out.println("Error Save Data" + e.getMessage());
            }
        }
    }//GEN-LAST:event_btnHapusBukuActionPerformed

    private void btnEditBukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditBukuActionPerformed
        // TODO add your handling code here:
        int selectedRow = tabelBuku.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a row to edit.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Ambil data dari baris yang dipilih
        String isbn = modelTabel.getValueAt(selectedRow, 0).toString();
        String judul = modelTabel.getValueAt(selectedRow, 1).toString();
        String penulis = modelTabel.getValueAt(selectedRow, 2).toString();
        int tahun; // Ubah menjadi tipe int
        try {
            tahun = Integer.parseInt(modelTabel.getValueAt(selectedRow, 3).toString());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid year format in the table. Please check the data.",
                    "Invalid Data", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String jenis = modelTabel.getValueAt(selectedRow, 4).toString();
        String penerbit = modelTabel.getValueAt(selectedRow, 5).toString();
        String stok = modelTabel.getValueAt(selectedRow, 6).toString();

        // Buka FormBuku dalam mode edit
        FormBuku fb = new FormBuku(this);
        fb.setDataForEdit(isbn, judul, penulis, tahun, jenis, penerbit, stok);
        fb.setSize(DesktopPane.getSize());// Mengisi data di form
        DesktopPane.add(fb);
        fb.setVisible(true);
    }//GEN-LAST:event_btnEditBukuActionPerformed

    private void btnTambahBukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTambahBukuActionPerformed
        // TODO add your handling code here:
        FormBuku fb = new FormBuku(this);
        fb.setSize(DesktopPane.getSize());
        DesktopPane.add(fb);
        fb.setVisible(true);
    }//GEN-LAST:event_btnTambahBukuActionPerformed

    private void cariBukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cariBukuActionPerformed
        // TODO add your handling code here:
        String keyword = tfCari.getText().trim();
        if (keyword.isEmpty()) {
            loadData(); // Jika tfCari kosong, tampilkan semua data
            return;
        }

        // Kosongkan tabel sebelum menambahkan data baru
        modelTabel.setRowCount(0);

        try {
            String sql = "SELECT * FROM t_buku WHERE judul_buku LIKE ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, "%" + keyword + "%");

            ResultSet hasil = ps.executeQuery();
            while (hasil.next()) {
                modelTabel.addRow(new Object[]{
                    hasil.getString("isbn"),
                    hasil.getString("judul_buku"),
                    hasil.getString("penulis"),
                    hasil.getString("tahun_terbit"),
                    hasil.getString("jenis_buku"),
                    hasil.getString("penerbit")
                });
            }
        } catch (SQLException e) {
            System.out.println("Error while searching: " + e.getMessage());
            JOptionPane.showMessageDialog(this, "Error while searching data",
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_cariBukuActionPerformed

    private void jLabel74MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel74MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel74MouseExited

    private void jLabel74MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel74MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel74MouseEntered

    private void jLabel74MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel74MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel74MouseClicked

    private void jLabel72MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel72MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel72MouseExited

    private void jLabel72MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel72MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel72MouseEntered

    private void jLabel72MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel72MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel72MouseClicked

    private void jLabel62MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel62MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel62MouseExited

    private void jLabel62MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel62MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel62MouseEntered

    private void jLabel62MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel62MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel62MouseClicked

    private void jLabel65MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel65MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel65MouseExited

    private void jLabel65MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel65MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel65MouseEntered

    private void jLabel65MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel65MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel65MouseClicked

    private void jLabel56MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel56MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel56MouseExited

    private void jLabel56MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel56MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel56MouseEntered

    private void jLabel56MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel56MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel56MouseClicked

    private void btnEditPinjamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditPinjamActionPerformed
        // TODO add your handling code here:
        int selectedRow = tabelPeminjaman.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a row to edit.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Ambil data dari baris yang dipilih
        try {
            int idPeminjaman = Integer.parseInt(modelTabelPeminjaman.getValueAt(selectedRow, 0).toString()); // Convert to int
            String idAnggota = modelTabelPeminjaman.getValueAt(selectedRow, 1).toString();
            String isbnBuku = modelTabelPeminjaman.getValueAt(selectedRow, 2).toString();
            String tglPinjam = modelTabelPeminjaman.getValueAt(selectedRow, 4).toString();
            String tglKembali = modelTabelPeminjaman.getValueAt(selectedRow, 5).toString();
            int jumlahBuku = Integer.parseInt(modelTabelPeminjaman.getValueAt(selectedRow, 6).toString()); // Convert to int

            // Buka FormPinjaman dalam mode edit
            FormPeminjaman fp = new FormPeminjaman(this); // Assuming 'this' is the parent frame
            fp.setDataForEdit(idPeminjaman, idAnggota, isbnBuku, tglPinjam, tglKembali, jumlahBuku);

            // Resize and show the form
            fp.setSize(DesktopPane3.getSize()); // DesktopPane is assumed to be your container
            DesktopPane3.add(fp);
            fp.setVisible(true);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid data format. Please check the table.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnEditPinjamActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want "
                + "to logout?", 
            "Confirm Exit", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            openLoginForm();
        }
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want "
                + "to exit?", 
            "Confirm Exit", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void btnHapusPinjamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHapusPinjamActionPerformed
        // TODO add your handling code here:
        int selectedRow = tabelPeminjaman.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Silahkan pilih data yang akan dihapus", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String id = modelTabelPeminjaman.getValueAt(selectedRow, 0).toString();

        int response = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to delete this data?",
            "Confirm Deletion",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);

        if (response == JOptionPane.YES_OPTION) {
            try {
                String sql = "DELETE FROM t_pinjam WHERE id_peminjaman = ?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, id);
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Data berhasil dihapus");
                loadDataPengembalian();
                tampilDataDashboard();
                simpanAktivitas("Menghapus pengembalian dengan id pengembalian : " + id);
                loadDataAktivitas();

            } catch (SQLException e) {
                System.out.println("Error Save Data" + e.getMessage());
            }
        }
    }//GEN-LAST:event_btnHapusPinjamActionPerformed

    private void btnHapusKembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHapusKembaliActionPerformed
        // TODO add your handling code here:
        int selectedRow = tabelPengembalian.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Silahkan pilih data yang akan dihapus", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String id = modelTabelPeminjaman.getValueAt(selectedRow, 0).toString();

        int response = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to delete this data?",
            "Confirm Deletion",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);

        if (response == JOptionPane.YES_OPTION) {
            try {
                String sql = "DELETE FROM t_kembali WHERE id_pengembalian = ?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, id);
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Data berhasil dihapus");
                loadDataPeminjaman();
                loadDataPengembalian();
                tampilDataDashboard();
                simpanAktivitas("Menghapus pengembalian dengan id pengembalian : " + id);
                loadDataAktivitas();

            } catch (SQLException e) {
                System.out.println("Error Save Data" + e.getMessage());
            }
        }

    }//GEN-LAST:event_btnHapusKembaliActionPerformed

    private void menuBuku1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuBuku1MouseClicked
        // TODO add your handling code here:
        tabbedPane.setSelectedIndex(1);
    }//GEN-LAST:event_menuBuku1MouseClicked

    private void menuAnggota1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuAnggota1MouseClicked
        // TODO add your handling code here:
        tabbedPane.setSelectedIndex(2);
    }//GEN-LAST:event_menuAnggota1MouseClicked

    private void menuPinjam1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuPinjam1MouseClicked
        // TODO add your handling code here:
        tabbedPane.setSelectedIndex(3);
    }//GEN-LAST:event_menuPinjam1MouseClicked

    private void menuKembali1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuKembali1MouseClicked
        // TODO add your handling code here:
        tabbedPane.setSelectedIndex(4);
    }//GEN-LAST:event_menuKembali1MouseClicked

    private void menuAktivitas1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuAktivitas1MouseClicked
        // TODO add your handling code here:
        tabbedPane.setSelectedIndex(5);
    }//GEN-LAST:event_menuAktivitas1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewJFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDesktopPane DesktopPane;
    private javax.swing.JDesktopPane DesktopPane1;
    private javax.swing.JDesktopPane DesktopPane3;
    private javax.swing.JDesktopPane DesktopPane4;
    private javax.swing.JPanel aktivitas;
    private javax.swing.JButton btnEditAnggota;
    private javax.swing.JButton btnEditBuku;
    private javax.swing.JButton btnEditPinjam;
    private javax.swing.JButton btnHapusAnggota;
    private javax.swing.JButton btnHapusBuku;
    private javax.swing.JButton btnHapusKembali;
    private javax.swing.JButton btnHapusPinjam;
    private javax.swing.JButton btnTambahAnggota;
    private javax.swing.JButton btnTambahBuku;
    private javax.swing.JButton btnTambahKembali;
    private javax.swing.JButton btnTambahPeminjaman;
    private javax.swing.JButton cariAnggota;
    private javax.swing.JButton cariBuku;
    private javax.swing.JButton cariKembali;
    private javax.swing.JButton cariPeminjaman;
    private javax.swing.JPanel dashboard;
    private javax.swing.JPanel dashboardInt;
    private javax.swing.JPanel dataAnggota;
    private javax.swing.JPanel dataBuku;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JLabel lblJmlAktivitas;
    private javax.swing.JLabel lblJmlAnggota;
    private javax.swing.JLabel lblJmlBuku;
    private javax.swing.JLabel lblJmlKembali;
    private javax.swing.JLabel lblJmlPinjam;
    private javax.swing.JPanel menuAktivitas1;
    private javax.swing.JPanel menuAnggota1;
    private javax.swing.JPanel menuBuku1;
    private javax.swing.JPanel menuKembali1;
    private javax.swing.JPanel menuPinjam1;
    private javax.swing.JPanel peminjaman;
    private javax.swing.JPanel pengembalian;
    private javax.swing.JTabbedPane tabbedPane;
    private javax.swing.JTable tabelAktivitas;
    private javax.swing.JTable tabelAnggota;
    private javax.swing.JTable tabelBuku;
    private javax.swing.JTable tabelPeminjaman;
    private javax.swing.JTable tabelPengembalian;
    private javax.swing.JTextField tfCari;
    private javax.swing.JTextField tfCariAnggota;
    private javax.swing.JTextField tfCariKembali;
    private javax.swing.JTextField tfCariPeminjaman;
    // End of variables declaration//GEN-END:variables
}
